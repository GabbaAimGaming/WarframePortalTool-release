#!/usr/bin/env python3
"""wfportal_builder - シミュレータ: フレーム性能・武器ダメージ・Riven の振れ幅の参考値を計算する

ブラウザ画面は web/wfportal_builder.html。ポータルのメニュー「シミュレータ」の中に表示する
(wfportal_ui.py の /builder。単独のページとしても開ける)。
計算はこのモジュールで行い、画面は /api/builder/* を呼び出して結果を表示するだけにしている
(計算を Python 側にまとめて、tests/test_builder.py で確かめられるようにするため)。

データ:
  - 公式 Public Export の ExportWarframes / ExportWeapons (英語・日本語) から必要な値だけを抜き出して
    データ置き場の builder.json に保存する(作るのは wfp/core/simdata、読むのは wfp/store/gamedata の read_builder)。
    「データ更新」のときに名前辞書と同じデータから作る(シミュレータの画面の「シミュレータ用データを取得」でも取得できる。
    取得元は名前辞書と同じ calamity-inc/warframe-public-export -> 失敗したら公式 Public Export から直接)。
  - Public Export に無いもの(アビリティの数値、MOD の効果量、Riven の基準値)は、
    下の表(WARFRAME Wiki 掲載値をもとにした参考値)を使う。ゲームの更新で変わることがあるので、
    画面では「参考値」と表示し、入力欄で値を直せるようにしている。

標準ライブラリのみ。非公式のファンツールです(Digital Extremes Ltd. とは関係ありません)。
"""
from __future__ import annotations

from pathlib import Path

from wfp.core.const import SIM_CATS, SIM_DAMAGE_TYPES
from wfp.core.errors import TextError
from wfp.core.i18n import txt
from wfp.store import gamedata


class BuilderError(TextError):
    """シミュレータの計算・入力のエラー。文はテキスト指定(画面は表示中の言語、str() は日本語)"""

    def __init__(self, text, status: int = 400):
        super().__init__(text)
        self.status = status


# --------------------------------------------------------------------------
# ダメージの種類 (ExportWeapons の damagePerShot は 20 要素の配列で、この順)
# --------------------------------------------------------------------------

# 表示名は wfp/core/const.py の SIM_DAMAGE_TYPES(画面は I18N の sim.dmg.<キー>)
DAMAGE_KEYS = tuple(SIM_DAMAGE_TYPES)
PHYSICAL = ("impact", "puncture", "slash")
PRIMARY_ELEMENTS = ("heat", "cold", "electricity", "toxin")
# 2つの基本属性 -> 複合属性
COMBINED = {
    frozenset(("heat", "cold")): "blast", frozenset(("electricity", "heat")): "radiation",
    frozenset(("heat", "toxin")): "gas", frozenset(("cold", "electricity")): "magnetic",
    frozenset(("cold", "toxin")): "viral", frozenset(("electricity", "toxin")): "corrosive",
}

CAT_JA = SIM_CATS  # 並びと表示名(画面は I18N の sim.cat.<キー>)

# ランク 30 で増える量 (Update 36 以降の多くのフレーム: ヘルス・シールド +100、エネルギー +50。例外のフレームもある)
RANK30_BONUS = {"health": 100.0, "shield": 100.0, "energy": 50.0}
ARMOR_CONSTANT = 300.0          # 被ダメージ軽減率 = アーマー / (アーマー + 300)
EFFICIENCY_CAP = 175.0          # アビリティ効率の上限(%)


# --------------------------------------------------------------------------
# MOD のプリセット (最大ランクの値・参考値。画面では入力欄に足し込むだけなので自由に直せる)
# --------------------------------------------------------------------------

FRAME_PRESETS = [
    {"en": "Vitality", "ja": "バイタリティ", "add": {"health_pct": 440}},
    {"en": "Redirection", "ja": "リダイレクション", "add": {"shield_pct": 440}},
    {"en": "Steel Fiber", "ja": "スチールファイバー", "add": {"armor_pct": 110}},
    {"en": "Flow", "ja": "フロー", "add": {"energy_pct": 150}},
    {"en": "Primed Flow", "ja": "プライム フロー", "add": {"energy_pct": 185}},
    {"en": "Intensify", "ja": "インテンシファイ", "add": {"strength": 30}},
    {"en": "Umbral Intensify", "ja": "アンブラル インテンシファイ", "add": {"strength": 44}},
    {"en": "Transient Fortitude", "ja": "トランジェント フォーティチュード", "add": {"strength": 55, "duration": -27.5}},
    {"en": "Blind Rage", "ja": "ブラインド レイジ", "add": {"strength": 99, "efficiency": -55}},
    {"en": "Continuity", "ja": "コンティニュイティ", "add": {"duration": 30}},
    {"en": "Primed Continuity", "ja": "プライム コンティニュイティ", "add": {"duration": 55}},
    {"en": "Narrow Minded", "ja": "ナローマインド", "add": {"duration": 99, "range": -66}},
    {"en": "Stretch", "ja": "ストレッチ", "add": {"range": 45}},
    {"en": "Augur Reach", "ja": "オーガー リーチ", "add": {"range": 30}},
    {"en": "Overextended", "ja": "オーバーエクステンド", "add": {"range": 90, "strength": -60}},
    {"en": "Streamline", "ja": "ストリームライン", "add": {"efficiency": 30}},
    {"en": "Fleeting Expertise", "ja": "フリーティング エクスパーティーズ", "add": {"efficiency": 60, "duration": -60}},
]
WEAPON_PRESETS = {
    "primary": [
        {"en": "Serration", "add": {"damage": 165}}, {"en": "Heavy Caliber", "add": {"damage": 165}},
        {"en": "Split Chamber", "add": {"multishot": 90}}, {"en": "Vigilante Armaments", "add": {"multishot": 60}},
        {"en": "Point Strike", "add": {"cc": 150}}, {"en": "Vital Sense", "add": {"cd": 120}},
        {"en": "Speed Trigger", "add": {"fire_rate": 60}}, {"en": "Rifle Aptitude", "add": {"status": 90}},
        {"en": "Point Blank", "add": {"damage": 90}}, {"en": "Hell's Chamber", "add": {"multishot": 120}},
        {"en": "Magazine Warp", "add": {"magazine": 30}}, {"en": "Fast Hands", "add": {"reload": 30}},
        {"en": "Hellfire", "element": ("heat", 90)}, {"en": "Cryo Rounds", "element": ("cold", 90)},
        {"en": "Stormbringer", "element": ("electricity", 90)}, {"en": "Infected Clip", "element": ("toxin", 90)},
        {"en": "Malignant Force", "element": ("toxin", 60), "add": {"status": 60}},
        {"en": "Bane of Grineer", "add": {"faction": 30}},
    ],
    "secondary": [
        {"en": "Hornet Strike", "add": {"damage": 220}}, {"en": "Barrel Diffusion", "add": {"multishot": 120}},
        {"en": "Lethal Torrent", "add": {"multishot": 60, "fire_rate": 60}}, {"en": "Pistol Gambit", "add": {"cc": 120}},
        {"en": "Target Cracker", "add": {"cd": 60}}, {"en": "Gunslinger", "add": {"fire_rate": 72}},
        {"en": "Heated Charge", "element": ("heat", 90)}, {"en": "Deep Freeze", "element": ("cold", 90)},
        {"en": "Convulsion", "element": ("electricity", 90)}, {"en": "Pathogen Rounds", "element": ("toxin", 90)},
    ],
    "melee": [
        {"en": "Pressure Point", "add": {"damage": 120}}, {"en": "Primed Pressure Point", "add": {"damage": 165}},
        {"en": "True Steel", "add": {"cc": 60}}, {"en": "Organ Shatter", "add": {"cd": 90}},
        {"en": "Fury", "add": {"fire_rate": 30}}, {"en": "Molten Impact", "element": ("heat", 90)},
        {"en": "North Wind", "element": ("cold", 90)}, {"en": "Shocking Touch", "element": ("electricity", 90)},
        {"en": "Fever Strike", "element": ("toxin", 90)},
    ],
}
WEAPON_PRESETS["archgun"] = WEAPON_PRESETS["primary"]
WEAPON_PRESETS["robotic"] = WEAPON_PRESETS["primary"]


# --------------------------------------------------------------------------
# Riven (WARFRAME Wiki 掲載の基準値。性質 1.0・最大ランク(8)・効果 2つ/マイナス無しの補正前の値)
#   値 = 基準値 × 性質値(RIVEN_DISPO = 1.2 固定)× 効果数による補正 × 乱数(0.9〜1.1)   ランク r では × (r + 1) / 9
#   取得元: https://wiki.warframe.com/w/Riven_Mods の「Base Values」「Spliced Values」と Overview Table
#   (2026-11-03 確認。Hotfix 44.1.3(2026-10-22)の性質値 1.2 固定・ショットガンのズーム追加の後)
# --------------------------------------------------------------------------

RIVEN_GROUPS = ("rifle", "shotgun", "pistol", "melee", "archgun")
# Riven の種類 (wfportal の RIVEN_TYPES_JA のキー) -> 基準値の列。Kitgun はピストル(Wiki の Pistol / Kitgun)、
# Zaw は近接(Wiki の Melee / Zaw)、コンパニオン武器はライフルで代用(Wiki では武器ごとに対応する列。推定)
RIVEN_TYPE_GROUP = {"Rifle Riven Mod": "rifle", "Shotgun Riven Mod": "shotgun", "Pistol Riven Mod": "pistol",
                    "Melee Riven Mod": "melee", "Zaw Riven Mod": "melee", "Kitgun Riven Mod": "pistol",
                    "Archgun Riven Mod": "archgun", "Companion Weapon Riven Mod": "rifle"}
# (効果の数, マイナス効果あり) -> (プラス効果の補正, マイナス効果の補正)
RIVEN_MODIFIERS = {(2, False): (0.99, 0.0), (2, True): (1.2375, -0.495),
                   (3, False): (0.75, 0.0), (3, True): (0.9375, -0.75)}
# 性質値(Riven の効果量にかかる倍率)。全武器が 1.2 に固定されたため、武器ごとの値は持たずこの1か所で決める
RIVEN_DISPO = 1.2
# スプライス効果は1枚に1つまで(Riven Splicer で2つの効果を1つにまとめたもの。常にプラス)
RIVEN_SPLICED_MAX = 1
# グレード(参考: Altair の Riven Grading の Classic)。ズレ = その効果の振れ幅の中央値から何 % 離れているか(-10〜+10)。
#   上から順に「ズレ >= 下限」なら そのグレード。どれにも当たらなければ RIVEN_GRADE_LOW。
#   マイナス効果は小さいほど良いので、ズレの符号を逆にしてから当てる(例外は効果の curse_up)。
#   振れ幅の外の値(読み違い・種類やランクの違い)は RIVEN_GRADE_OUT
RIVEN_GRADES = [(9.5, "S"), (7.5, "A+"), (5.5, "A"), (3.5, "A-"), (1.5, "B+"), (-1.5, "B"),
                (-3.5, "B-"), (-5.5, "C+"), (-7.5, "C"), (-9.5, "C-")]
RIVEN_GRADE_LOW = "F"
RIVEN_GRADE_OUT = "?"
RIVEN_GRADE_TOL = 0.05  # 値の許容差(ゲームの表示は小数1桁で丸めているので、その半分)
_G = lambda rifle=None, shotgun=None, pistol=None, melee=None, archgun=None: {  # noqa: E731
    k: v for k, v in (("rifle", rifle), ("shotgun", shotgun), ("pistol", pistol), ("melee", melee), ("archgun", archgun)) if v is not None}
_GUNS = lambda v: _G(v, v, v, None, v)  # noqa: E731
_ALL = lambda v: _G(v, v, v, v, v)  # noqa: E731
# 1行 = 1つの効果:
#   base       プラス効果の基準値(列 = Riven の種類。無い列の種類には付かない)
#   curse_base マイナス効果のときだけ使う基準値(無ければ base と同じ)
#   no_curse   マイナス効果にならない種類(Wiki の Overview Table でマイナスの欄が「—」のもの)
#   spliced    スプライス効果(常にプラス。1枚に RIVEN_SPLICED_MAX まで)
RIVEN_STATS = [
    {"key": "cc", "unit": "%", "base": _G(149.99, 90, 149.99, 180, 99.9)},
    {"key": "cd", "unit": "%", "base": _G(119.997, 90, 90, 90, 80.1)},
    {"key": "damage", "unit": "%", "base": _G(165, 164.7, 219.6, 164.7, 99.9), "no_curse": ["melee"]},
    {"key": "multishot", "unit": "%", "base": _G(90, 119.7, 119.7, None, 60.3)},
    {"key": "fire_rate", "unit": "%", "base": _G(60.03, 90, 74.7, 54.9, 60.03)},
    {"key": "status", "unit": "%", "base": _G(90, 90, 90, 90, 60.3)},
    {"key": "status_duration", "unit": "%", "base": _ALL(99.99)},
    {"key": "heat", "unit": "%", "base": _G(90, 90, 90, 90, 119.7), "no_curse": list(RIVEN_GROUPS)},
    {"key": "cold", "unit": "%", "base": _G(90, 90, 90, 90, 119.7), "no_curse": list(RIVEN_GROUPS)},
    {"key": "electricity", "unit": "%", "base": _G(90, 90, 90, 90, 119.7), "no_curse": list(RIVEN_GROUPS)},
    {"key": "toxin", "unit": "%", "base": _G(90, 90, 90, 90, 119.7), "no_curse": list(RIVEN_GROUPS)},
    {"key": "impact", "unit": "%", "base": _G(119.97, 119.97, 119.97, 119.7, 90)},
    {"key": "puncture", "unit": "%", "base": _G(119.997, 119.997, 119.997, 119.997, 90)},
    {"key": "slash", "unit": "%", "base": _G(119.97, 119.97, 119.97, 119.7, 90)},
    {"key": "faction", "unit": "%", "base": _ALL(45)},
    {"key": "magazine", "unit": "%", "base": _G(49.995, 49.995, 49.995, None, 60.3)},
    {"key": "reload", "unit": "%", "base": _G(49.995, 49.995, 49.995, None, 99.9)},
    {"key": "ammo", "unit": "%", "base": _G(49.95, 90, 90, None, 99.9)},
    {"key": "projectile_speed", "unit": "%", "base": _G(90, 90, 90)},
    # 反動は Wiki の係数が負(-0.01)なので基準値も負にする。プラス効果はマイナスの値(反動が減る)、マイナス効果はプラスの値になる
    # curse_up: マイナス効果でも、値が大きいほど上のグレードにする(グレードの向きを逆にしない。2026-11-03 利用者の指定)
    {"key": "recoil", "unit": "%", "base": _GUNS(-90), "curse_up": True},
    {"key": "zoom", "unit": "%", "base": _G(59.99, 41.994, 80.1, None, 59.99)},
    {"key": "punch_through", "unit": "m", "base": _GUNS(2.7), "no_curse": list(RIVEN_GROUPS)},
    {"key": "range", "unit": "m", "base": _G(melee=1.94)},
    {"key": "combo_duration", "unit": "s", "base": _G(melee=8.1)},
    {"key": "initial_combo", "unit": "", "base": _G(melee=24.5)},
    {"key": "slide_cc", "unit": "%", "base": _G(melee=120)},
    {"key": "finisher", "unit": "%", "base": _G(melee=119.7)},
    {"key": "heavy_efficiency", "unit": "%", "base": _G(melee=73.44)},
    # Wiki ではプラスが Additional Combo Count Chance、マイナスが Chance to Gain Combo Count(基準値が違う)。1つの効果として扱う
    {"key": "combo_chance", "unit": "%", "base": _G(melee=58.77), "curse_base": _G(melee=104.85)},
    # スプライス効果
    {"key": "ammo_efficiency", "unit": "%", "base": _GUNS(45), "spliced": True},
    {"key": "blast", "unit": "%", "base": _ALL(90), "spliced": True},
    {"key": "corrosive", "unit": "%", "base": _ALL(90), "spliced": True},
    {"key": "gas", "unit": "%", "base": _ALL(90), "spliced": True},
    {"key": "magnetic", "unit": "%", "base": _ALL(90), "spliced": True},
    {"key": "radiation", "unit": "%", "base": _ALL(90), "spliced": True},
    {"key": "viral", "unit": "%", "base": _ALL(90), "spliced": True},
    {"key": "faction_spliced", "unit": "%", "base": _ALL(45), "spliced": True},  # Orokin・Scaldra・Techrot
    {"key": "status_damage", "unit": "%", "base": _ALL(90), "spliced": True},
    {"key": "reload_holstered", "unit": "%", "base": _G(90, 90, 90), "spliced": True},
    {"key": "weakpoint_damage", "unit": "%", "base": _GUNS(225), "spliced": True},
    {"key": "weakpoint_cc", "unit": "%", "base": _GUNS(247.5), "spliced": True},
    {"key": "heavy_windup", "unit": "%", "base": _G(melee=119.7), "spliced": True},
    {"key": "heavy_damage", "unit": "%", "base": _G(melee=119.7), "spliced": True},
    {"key": "slam_damage", "unit": "%", "base": _G(melee=119.7), "spliced": True},
    {"key": "parry_angle", "unit": "%", "base": _G(melee=81), "spliced": True},
]
for _st in RIVEN_STATS:  # スプライス効果はマイナスにならない
    if _st.get("spliced"):
        _st["no_curse"] = list(RIVEN_GROUPS)
RIVEN_STAT_INDEX = {s["key"]: s for s in RIVEN_STATS}


# --------------------------------------------------------------------------
# 計算: フレーム
# --------------------------------------------------------------------------

def _get(mods: dict | None, key: str) -> float:
    try:
        return float((mods or {}).get(key) or 0)
    except (TypeError, ValueError):
        raise BuilderError(f"数字で入力してください: {key}")


def damage_reduction(armor: float) -> float:
    """アーマーによる被ダメージ軽減率 (0〜1)"""
    armor = max(0.0, armor)
    return armor / (armor + ARMOR_CONSTANT)


def frame_stats(frame: dict, mods: dict | None = None, rank30: bool = True, rank_bonus: dict | None = None) -> dict:
    """フレームの性能(ヘルス・シールド・アーマー・エネルギー)とアビリティ性能の倍率

    mods: health_pct / shield_pct / armor_pct / energy_pct (%)、health_flat などの固定値、
          strength / duration / range / efficiency (アビリティ性能の増減 %。100% からの差)
    """
    bonus = {**RANK30_BONUS, **{k: float(v) for k, v in (rank_bonus or {}).items() if k in RANK30_BONUS}}
    rows = {}
    for key in ("health", "shield", "armor", "energy"):
        base = float(frame.get(key) or 0)
        ranked = base + (bonus.get(key, 0.0) if rank30 else 0.0)
        modded = ranked * (1 + _get(mods, f"{key}_pct") / 100) + _get(mods, f"{key}_flat")
        rows[key] = {"base": base, "ranked": ranked, "modded": max(0.0, modded)}
    dr = damage_reduction(rows["armor"]["modded"])
    health, shield = rows["health"]["modded"], rows["shield"]["modded"]
    strength = 100 + _get(mods, "strength")
    duration = 100 + _get(mods, "duration")
    rng = 100 + _get(mods, "range")
    eff_raw = 100 + _get(mods, "efficiency")
    efficiency = min(EFFICIENCY_CAP, eff_raw)
    return {
        "stats": rows, "damage_reduction": dr,
        "ehp": health / (1 - dr) + shield,
        "ability": {"strength": strength, "duration": duration, "range": rng, "efficiency": efficiency,
                    "efficiency_raw": eff_raw, "efficiency_capped": eff_raw > EFFICIENCY_CAP,
                    "cost": max(0.0, 200 - efficiency)},
    }


def ability_value(base: float, scale: str, ability: dict) -> float:
    """アビリティの基準値(Wiki などで調べた値)に、どのステータスで伸びるかを掛けた参考値

    scale: strength / duration / range / cost (エネルギー消費) / inv_duration (持続時間で短くなるもの) / none
    """
    if scale == "strength":
        return base * ability["strength"] / 100
    if scale == "duration":
        return base * ability["duration"] / 100
    if scale == "range":
        return base * ability["range"] / 100
    if scale == "cost":
        return base * ability["cost"] / 100
    if scale == "inv_duration":
        return base * 100 / ability["duration"] if ability["duration"] > 0 else float("inf")
    return base


# --------------------------------------------------------------------------
# 計算: 武器
# --------------------------------------------------------------------------

def modded_damage(weapon: dict, mods: dict | None = None) -> dict[str, float]:
    """MOD 適用後の1発(1ヒット)あたりのダメージ内訳 (クリティカル・マルチショット・勢力は含まない)

    - ダメージ MOD は全体に掛かる。衝撃/貫通/切断の MOD は、その種類の基礎値にだけ掛かる
    - 属性 MOD は「ダメージ MOD 適用後の基礎ダメージ合計 × 属性 %」を追加する
    - 属性は MOD の並び順に2つずつ複合する。武器に元からある属性は最後に加わる
      (同じ属性の MOD があれば、その MOD の位置で合算する)
    """
    base = {k: float(v) for k, v in (weapon.get("damage") or {}).items() if float(v) > 0}
    total = sum(base.values())
    dmg_mult = 1 + _get(mods, "damage") / 100
    out: dict[str, float] = {}
    for k, v in base.items():
        mult = dmg_mult * (1 + _get(mods, k) / 100) if k in PHYSICAL else dmg_mult
        out[k] = v * mult
    order: list[str] = []
    amount: dict[str, float] = {}
    for e in (mods or {}).get("elements") or []:
        if not isinstance(e, dict):
            continue
        t, pct = str(e.get("type") or ""), _get(e, "pct")
        if t not in PRIMARY_ELEMENTS or not pct:
            continue
        if t not in order:
            order.append(t)
        amount[t] = amount.get(t, 0.0) + total * dmg_mult * pct / 100
    for t in PRIMARY_ELEMENTS:  # 元からある基本属性は最後
        if t in out:
            if t not in order:
                order.append(t)
            amount[t] = amount.get(t, 0.0) + out.pop(t)
    for i in range(0, len(order) - 1, 2):
        a, b = order[i], order[i + 1]
        c = COMBINED[frozenset((a, b))]
        out[c] = out.get(c, 0.0) + amount[a] + amount[b]
    if len(order) % 2:
        t = order[-1]
        out[t] = out.get(t, 0.0) + amount[t]
    return {k: v for k, v in out.items() if v > 0}


def weapon_stats(weapon: dict, mods: dict | None = None) -> dict:
    """MOD 適用後の武器性能と DPS の参考値

    mods: damage / multishot / cc / cd / fire_rate / status / faction / magazine / reload /
          impact / puncture / slash (いずれも %) と elements [{type, pct}]
    """
    melee = weapon.get("cat") == "melee"
    per_hit = modded_damage(weapon, mods)
    per_hit_total = sum(per_hit.values())
    cc = weapon.get("cc", 0) * (1 + _get(mods, "cc") / 100)
    cd = weapon.get("cd", 1) * (1 + _get(mods, "cd") / 100)
    crit_avg = 1 + max(0.0, cc) * (cd - 1)
    multishot = 1.0 if melee else weapon.get("multishot", 1) * (1 + _get(mods, "multishot") / 100)
    fire_rate = weapon.get("fire_rate", 1) * (1 + _get(mods, "fire_rate") / 100)
    status = weapon.get("sc", 0) * (1 + _get(mods, "status") / 100)
    faction = 1 + _get(mods, "faction") / 100
    burst = per_hit_total * crit_avg * multishot * max(0.0, fire_rate) * faction
    out = {
        "melee": melee,
        "damage": [{"key": k, "value": v, "share": v / per_hit_total if per_hit_total else 0}
                   for k, v in sorted(per_hit.items(), key=lambda x: -x[1])],
        "per_hit": per_hit_total, "cc": cc, "cd": cd, "crit_avg": crit_avg, "multishot": multishot,
        "fire_rate": fire_rate, "status": status, "status_per_sec": status * multishot * max(0.0, fire_rate),
        "faction": faction, "per_shot_avg": per_hit_total * crit_avg * multishot * faction, "burst_dps": burst,
    }
    if not melee and weapon.get("magazine") and weapon.get("reload"):
        mag = max(1, round(weapon["magazine"] * (1 + _get(mods, "magazine") / 100)))
        reload = weapon["reload"] / max(0.01, 1 + _get(mods, "reload") / 100)
        empty = mag / fire_rate if fire_rate > 0 else 0
        out.update(magazine=mag, reload=reload, mag_time=empty,
                   sustained_dps=burst * empty / (empty + reload) if empty + reload > 0 else 0)
    return out


# --------------------------------------------------------------------------
# 計算: Riven の振れ幅
# --------------------------------------------------------------------------

def riven_group(riven_type: str) -> str:
    return RIVEN_TYPE_GROUP.get(riven_type, "rifle")


def weapon_riven_type(weapon: dict, dispo_rows: list[dict] | None = None) -> str:
    """武器の Riven の種類。names.json の Riven 性質(ライフル/ショットガンの判定済み)があればそれを使う"""
    for r in dispo_rows or []:
        if r.get("en", "").lower() == weapon["en"].lower() and r.get("cat") == weapon["cat"] and not r.get("variant"):
            return r.get("type") or ""
    return {"primary": "Shotgun Riven Mod" if weapon.get("shotgun") else "Rifle Riven Mod",
            "secondary": "Pistol Riven Mod", "melee": "Melee Riven Mod", "archgun": "Archgun Riven Mod",
            "robotic": "Companion Weapon Riven Mod"}.get(weapon.get("cat"), "Rifle Riven Mod")


def riven_can_curse(st: dict, group: str) -> bool:
    """その種類の Riven で、この効果がマイナス効果になれるか"""
    return group in st["base"] and group not in st.get("no_curse", ())


def riven_base(st: dict, group: str, negative: bool = False) -> float:
    """効果の基準値。マイナス効果で curse_base があればそちら"""
    if negative and group in st.get("curse_base", {}):
        return st["curse_base"][group]
    return st["base"][group]


def riven_range(base: float, dispo: float, buffs: int, curse: bool, negative: bool = False, rank: int = 8) -> tuple[float, float]:
    """1つの効果の振れ幅 (最小, 最大)。マイナス効果は負の値で返す"""
    if (buffs, curse) not in RIVEN_MODIFIERS:
        raise BuilderError(txt("err.sim.buffs.n"))
    if negative and not curse:
        raise BuilderError(txt("err.sim.nocurse"))
    if not 0 <= rank <= 8:
        raise BuilderError(txt("err.sim.rank"))
    buff_m, curse_m = RIVEN_MODIFIERS[(buffs, curse)]
    v = base * dispo * (curse_m if negative else buff_m) * (rank + 1) / 9
    lo, hi = v * 0.9, v * 1.1
    return (min(lo, hi), max(lo, hi))


def riven_calc(group: str, buffs: list[str], curse: str | None, rank: int = 8) -> dict:
    """Riven の効果ごとの振れ幅。性質値は RIVEN_DISPO(1.2 固定。武器ごとの値は持たない)"""
    dispo = RIVEN_DISPO
    if group not in RIVEN_GROUPS:
        raise BuilderError(txt("err.sim.group"))
    if len(buffs) not in (2, 3):
        raise BuilderError(txt("err.sim.buffs"))
    keys = list(buffs) + ([curse] if curse else [])
    if len(set(keys)) != len(keys):
        raise BuilderError(txt("err.sim.dup"))
    rows = []
    for i, k in enumerate(keys):
        st = RIVEN_STAT_INDEX.get(k)
        if st is None or group not in st["base"]:
            raise BuilderError(txt("err.sim.stat", group=txt("sim.group." + group), stat=txt("sim.stat." + k, k)))
        neg = i >= len(buffs)
        if neg and not riven_can_curse(st, group):
            raise BuilderError(txt("err.sim.curse.stat", stat=txt("sim.stat." + k, k)))
        base = riven_base(st, group, neg)
        lo, hi = riven_range(base, dispo, len(buffs), bool(curse), negative=neg, rank=rank)
        lo0, hi0 = riven_range(base, dispo, len(buffs), bool(curse), negative=neg, rank=0)
        rows.append({"key": k, "unit": st["unit"], "negative": neg, "spliced": bool(st.get("spliced")), "base": base,
                     "min": lo, "max": hi, "min_r0": lo0, "max_r0": hi0})
    if sum(r["spliced"] for r in rows) > RIVEN_SPLICED_MAX:
        raise BuilderError(txt("err.sim.spliced", n=RIVEN_SPLICED_MAX))
    return {"group": group, "dispo": dispo, "rank": rank, "rows": rows}


def riven_grade_letter(score: float) -> str:
    """ズレ(向きをそろえた後の値。-10〜+10)-> グレード"""
    for low, grade in RIVEN_GRADES:
        if score >= low:
            return grade
    return RIVEN_GRADE_LOW


def riven_grade(group: str, stats: list[dict], rank: int = 8) -> dict:
    """Riven の効果の値からグレードを出す。stats = [{"key", "value", "tol"(任意)}](ゲームの表示の値。単位なし)。
    マイナス効果かどうかは値の符号と基準値の符号で決める(反動はマイナスの値がプラス効果)。効果の数・マイナス効果の有無は
    stats から数えて、振れ幅は riven_calc と同じ式で出す"""
    rows_in = []
    for st in stats or []:
        key = str(st.get("key") or "")
        try:
            value = float(st.get("value"))
            tol = float(st.get("tol", RIVEN_GRADE_TOL))
        except (TypeError, ValueError):
            raise BuilderError(txt("err.sim.grade.value", stat=txt("sim.stat." + key, key)))
        info = RIVEN_STAT_INDEX.get(key)
        if info is None or group not in info["base"]:
            raise BuilderError(txt("err.sim.stat", group=txt("sim.group." + group) if group in RIVEN_GROUPS else group,
                                   stat=txt("sim.stat." + key, key)))
        if value == 0:
            raise BuilderError(txt("err.sim.grade.value", stat=txt("sim.stat." + key, key)))
        rows_in.append({"key": key, "value": value, "tol": max(0.0, tol),
                        "negative": (value < 0) != (info["base"][group] < 0)})
    buffs = [r["key"] for r in rows_in if not r["negative"]]
    curses = [r["key"] for r in rows_in if r["negative"]]
    if len(curses) > 1:
        raise BuilderError(txt("err.sim.grade.curses"))
    calc = riven_calc(group, buffs, curses[0] if curses else None, rank)
    ranges = {r["key"]: r for r in calc["rows"]}
    rows, scores = [], []
    for r in rows_in:
        rg = ranges[r["key"]]
        lo, hi = abs(rg["min"]), abs(rg["max"])
        lo, hi = min(lo, hi), max(lo, hi)
        mid = (lo + hi) / 2
        mag = abs(r["value"])
        dev = (mag / mid - 1) * 100
        out = not (lo - r["tol"] <= mag <= hi + r["tol"])
        dev_c = max(-10.0, min(10.0, dev))  # 許容差の分だけはみ出したものは端に寄せる
        flip = r["negative"] and not RIVEN_STAT_INDEX[r["key"]].get("curse_up")
        score = None if out else (-dev_c if flip else dev_c)
        if score is not None:
            scores.append(score)
        rows.append({"key": r["key"], "unit": rg["unit"], "value": r["value"], "negative": r["negative"],
                     "spliced": rg["spliced"], "min": rg["min"], "max": rg["max"], "mid": mid * (1 if rg["max"] > 0 else -1),
                     "dev": dev, "score": score, "out": out,
                     "grade": RIVEN_GRADE_OUT if out else riven_grade_letter(score)})
    avg = sum(scores) / len(scores) if scores else None
    return {"group": group, "dispo": RIVEN_DISPO, "rank": rank, "buffs": len(buffs), "curse": bool(curses), "rows": rows,
            "score": avg, "grade": None if avg is None else riven_grade_letter(avg),
            "complete": len(scores) == len(rows)}


# --------------------------------------------------------------------------
# 画面(wfportal_ui.py)から呼ぶ API
# --------------------------------------------------------------------------

def _need_data(d: Path) -> dict:
    data = gamedata.read_builder(d)
    if data is None:
        raise BuilderError(txt("err.sim.nodata"), 409)
    return data


def _find(items: list[dict], name: str, cat: str | None = None) -> dict:
    n = str(name or "").strip().lower()
    hits = [x for x in items if n in (x["en"].lower(), x["ja"].lower()) and (not cat or x.get("cat") == cat)]
    if not hits:
        raise BuilderError(txt("err.sim.unknown", name=str(name)), 404)
    return hits[0]


def api_data(d: Path, dispo_rows: list[dict] | None = None) -> dict:
    data = gamedata.read_builder(d)
    # 種類・効果・ダメージの種類・カテゴリーはキーだけ(表示名は画面の I18N の sim.group / sim.stat / sim.dmg / sim.cat)
    riven = {"groups": list(RIVEN_GROUPS), "stats": RIVEN_STATS, "spliced_max": RIVEN_SPLICED_MAX,
             "grades": RIVEN_GRADES, "grade_low": RIVEN_GRADE_LOW,
             "modifiers": [{"buffs": b, "curse": c, "buff": m[0], "curse_m": m[1]} for (b, c), m in RIVEN_MODIFIERS.items()]}
    meta = {"cats": list(CAT_JA), "damage_types": list(DAMAGE_KEYS), "elements": list(PRIMARY_ELEMENTS),
            "frame_presets": FRAME_PRESETS, "weapon_presets": WEAPON_PRESETS, "rank30_bonus": RANK30_BONUS,
            "riven": riven, "riven_type_group": RIVEN_TYPE_GROUP}
    if data is None:
        return {"has_data": False, **meta}
    weapons = [{**w, "riven_type": weapon_riven_type(w, dispo_rows)} for w in data["weapons"]]
    return {"has_data": True, "updated": data.get("updated"), "source": data.get("source"),
            "frames": data["frames"], "weapons": weapons, **meta}


def api_frame(d: Path, body: dict) -> dict:
    frame = _find(_need_data(d)["frames"], body.get("name"))
    res = frame_stats(frame, body.get("mods"), rank30=bool(body.get("rank30", True)), rank_bonus=body.get("rank_bonus"))
    refs = []
    for r in body.get("refs") or []:
        try:
            base = float(r.get("base"))
        except (TypeError, ValueError, AttributeError):
            continue
        refs.append({"id": r.get("id"), "value": ability_value(base, str(r.get("scale") or "none"), res["ability"])})
    return {"frame": frame, **res, "refs": refs}


def api_weapon(d: Path, body: dict, dispo_rows: list[dict] | None = None) -> dict:
    weapon = _find(_need_data(d)["weapons"], body.get("name"), body.get("cat"))
    weapon = {**weapon, "riven_type": weapon_riven_type(weapon, dispo_rows)}
    return {"weapon": weapon, **weapon_stats(weapon, body.get("mods"))}


def _riven_target(d: Path, body: dict, dispo_rows: list[dict] | None) -> tuple[dict | None, int, str]:
    """Riven の計算の前半(api_riven・api_riven_grade で共通): 武器(name・cat があれば)・ランク・種類(group が無ければ武器から。武器も無ければ rifle)"""
    weapon = None
    if body.get("name"):
        weapon = _find(_need_data(d)["weapons"], body.get("name"), body.get("cat"))
    try:
        rank = int(body.get("rank", 8))
    except (TypeError, ValueError):
        raise BuilderError(txt("err.sim.rank.num"))
    group = body.get("group") or (riven_group(weapon_riven_type(weapon, dispo_rows)) if weapon else "rifle")
    return weapon, rank, group


def _weapon_ref(weapon: dict | None) -> dict | None:
    return {"en": weapon["en"], "ja": weapon["ja"]} if weapon else None


def api_riven(d: Path, body: dict, dispo_rows: list[dict] | None = None) -> dict:
    weapon, rank, group = _riven_target(d, body, dispo_rows)
    buffs = [str(x) for x in body.get("buffs") or [] if x]
    res = riven_calc(group, buffs, str(body.get("curse")) if body.get("curse") else None, rank)
    res["weapon"] = _weapon_ref(weapon)
    return res


def api_riven_grade(d: Path, body: dict, dispo_rows: list[dict] | None = None) -> dict:
    """POST /api/builder/riven/grade: {name, cat, group, rank, stats: [{key, value, tol}]}。group が無ければ武器から決める"""
    weapon, rank, group = _riven_target(d, body, dispo_rows)
    if group not in RIVEN_GROUPS:
        raise BuilderError(txt("err.sim.group"))
    stats = body.get("stats")
    if not isinstance(stats, list) or not all(isinstance(x, dict) for x in stats):
        raise BuilderError(txt("err.sim.grade.stats"))
    res = riven_grade(group, stats, rank)
    res["weapon"] = _weapon_ref(weapon)
    return res
