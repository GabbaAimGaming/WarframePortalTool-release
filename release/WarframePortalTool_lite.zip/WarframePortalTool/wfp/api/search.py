"""画面向け API: 検索(アイテムから探す・エリア検索・敵から探す・要求素材集)"""
from __future__ import annotations

from wfp.api.store import ApiError, Store, need_drops
from wfp.core.common import rank
from wfp.core.i18n import name_txt, txt
from wfp.core.text import norm
from wfp.core.const import (
    AREA_KINDS, ENEMY_KIND_DEFAULT, ITEM_KIND_DEFAULT, MASTERY_CATS, PART_SKIP_CATS, PLANETS_JA, RECIPE_SOURCE_LIMIT,
    RECIPE_SUGGEST_LIMIT, SOURCE_CATS,
)
from wfp.core.names import item_key
from wfp.core.recipes import Recipes, pick_tops, sort_sources
from wfp.drops.search import area_stages, enemy_drops, find_sources, group_candidates, parse_kinds, pick_candidates, pick_enemies
from wfp.drops.tables import mission_place, stage_label


SUGGEST_LIMIT = 10  # 候補として返す最大件数(数量違いを束ねた後)
ENEMY_SUGGEST_LIMIT = 20  # 敵から探すの候補の最大件数(同じ敵の勢力・強化版の違いが多いので、アイテムより多め)


def suggest_items(store: Store, q: str, kinds: set[str], cat: str = "", no_prime: bool = False) -> dict:
    """アイテムから探すの候補。種類(AREA_KINDS のキー。Names.item_kind)が kinds に入る項目だけを返す。

    items は候補(最大 SUGGEST_LIMIT 件。kind は種類のキー、パーツなら cat にカテゴリー)、total は絞った後の全件数。
    パーツ(part)だけに効く絞り込み: cat はマスター一覧のカテゴリー(MASTERY_CATS)、
    no_prime は入手先にレリックがある項目(Sources.relic_items)を除く(画面の「Prime を除外する」。名前ではなく入手先で判定するので、
    バウンティで出る Galariak Prime などは残る)。ほかの種類はどちらにも影響されない。
    cats はパーツのカテゴリーごとの件数(q と種類に合うもの。cat で絞る前。並びは MASTERY_CATS)。名前は画面の I18N(mastery.cat.<キー>)
    """
    if cat and (cat not in MASTERY_CATS or cat in PART_SKIP_CATS):
        raise ApiError(txt("err.part.cat"), 400)
    need_drops(store)
    names, src = store.names(), store.sources()
    owners = src.part_owner if src else {}
    relic = src.relic_items if src and no_prime else set()
    kind_of: dict[str, str] = {}
    for n in store.all_items():
        kind = names.item_kind(n, owners)
        if kind in kinds and not (kind == "part" and item_key(n) in relic):
            kind_of[n] = kind
    if q.strip():
        cands = pick_candidates(q, kind_of, names)
    else:
        cands = sorted(kind_of, key=lambda n: norm(names.ja(n)))
    rows = []
    counts: dict[str, int] = {}
    for base in group_candidates(cands, names).values():  # 数量違いを束ねた、表示に使う英名
        kind = names.item_kind(base, owners)
        part_cat = names.part_of(base, owners)[1] if kind == "part" else ""
        if part_cat:
            counts[part_cat] = counts.get(part_cat, 0) + 1
        if not cat or kind != "part" or part_cat == cat:
            rows.append({"key": base, "ja": names.ja(base), "en": base, "kind": kind, "cat": part_cat})
    return {
        "total": len(rows),
        "cats": [{"key": c, "n": counts[c]} for c in MASTERY_CATS if c in counts],
        "items": rows[:SUGGEST_LIMIT],
    }


def lookup_item(store: Store, key: str, events: bool) -> dict:
    drops, names = need_drops(store), store.names()
    rows = find_sources(key, drops, store.sources(), names, events=events)
    if not rows:
        raise ApiError(txt("err.item.none"), 404)
    counts: dict[str, int] = {}
    for r in rows:
        counts[r["cat"]] = counts.get(r["cat"], 0) + 1
    return {
        "ja": names.ja(key), "en": key, "total": len(rows),
        "cats": [{"key": c, "n": counts[c]} for c in SOURCE_CATS if c in counts],  # 種類の名前は画面の I18N(src.cat.<キー>)
        "rows": rows,  # rarity はキー。place・detail・stage はテキスト指定
    }


def planets(store: Store) -> list[dict]:
    """惑星の一覧。name は表示名のテキスト指定(画面の I18N の planet.<英名>)"""
    drops = need_drops(store)
    return [{"type": "planet", "key": p, "name": name_txt("planet.", p)} for p in drops.planets]


def suggest_areas(store: Store, q: str) -> list[dict]:
    """惑星・ノードの候補。惑星は英名・日本語名(PLANETS_JA)のどちらでも探せる。ノード名は英語(sub は惑星のテキスト指定)"""
    drops = need_drops(store)
    if not q.strip():
        return planets(store)
    out = [p for p in planets(store) if rank(q, [p["key"], PLANETS_JA.get(p["key"], p["key"])]) is not None]
    for planet, node in drops.node_order:
        if rank(q, [node]) is not None:
            out.append({"type": "node", "key": f"{planet}|{node}", "name": node, "sub": name_txt("planet.", planet)})
    return out[:80]


def lookup_area(store: Store, kind: str, key: str, kinds: set[str], events: bool) -> dict:
    """惑星・ノードのドロップをステージごとに返す。kinds は出す種類(AREA_KINDS のキー)の集まり。
    各アイテムの kind は種類のキー(画面は I18N の area.kind.<キー>)"""
    drops, names = need_drops(store), store.names()
    if kind == "planet":
        targets = [(p, n) for p, n in drops.node_order if p == key]
        title = name_txt("planet.", key)
    else:
        planet, _, node = key.partition("|")
        targets = [(planet, node)]
        title = mission_place(planet, node)
    nodes = []
    for planet, node in targets:
        rows = [r for r in drops.rows if r[0] == planet and r[1] == node]
        if not rows or (rows[0][3] and not events):
            continue
        stages = [{"stage": stage_label(rot), "items": [{
            "ja": names.ja(r[5]), "en": r[5], "chance": r[6], "rarity": r[7], "kind": item_kind,
        } for r, item_kind in lst]} for rot, lst in area_stages(rows, names, kinds).items()]
        if stages or kind == "node":
            nodes.append({"planet": name_txt("planet.", planet), "node": node,
                          "mode": name_txt("mode.", rows[0][2]), "event": rows[0][3], "stages": stages})
    return {"title": title, "nodes": nodes}


def suggest_enemies(store: Store, q: str) -> dict:
    """敵から探すの候補。敵の名前は英名だけ(和名の出どころが無い)。q が空なら候補は出さない(千件以上あるため)。
    items は候補(最大 ENEMY_SUGGEST_LIMIT 件)、total は q に合う全件数"""
    need_drops(store)
    src = store.sources()
    cands = pick_enemies(q, src.enemies if src else [])
    return {"total": len(cands), "items": [{"key": n, "name": n} for n in cands[:ENEMY_SUGGEST_LIMIT]]}


def lookup_enemy(store: Store, name: str, kinds: set[str]) -> dict:
    """1体の敵が落とすアイテム(drops/search の enemy_drops)。kinds は出す種類(AREA_KINDS のキー)の集まり。
    知らない敵は 404。total は種類で絞る前の件数、kinds_n は種類ごとの件数(並びは AREA_KINDS)"""
    need_drops(store)
    src, names = store.sources(), store.names()
    if not src or name not in src.enemies:
        raise ApiError(txt("err.enemy.none"), 404)
    every = enemy_drops(name, src, names, set(AREA_KINDS))
    counts: dict[str, int] = {}
    for r in every:
        counts[r["kind"]] = counts.get(r["kind"], 0) + 1
    return {
        "name": name, "total": len(every),
        "kinds_n": [{"key": k, "n": counts[k]} for k in AREA_KINDS if k in counts],
        "items": [r for r in every if r["kind"] in kinds],  # detail はテキスト指定、kind・rarity はキー
    }


def _need_recipes(store: Store) -> Recipes:
    """要求素材集の設計図。まだ無ければ(データ更新の前)409"""
    recipes = store.recipes()
    if not recipes:
        raise ApiError(txt("err.recipes.nodata"), 409)
    return recipes


def suggest_recipes(store: Store, q: str) -> dict:
    """要求素材集の候補(マスター一覧に載っていて設計図があるもの。core/recipes の Recipes.tops)。

    items は候補 [{key: 内部パス, en, ja, cat}](最大 RECIPE_SUGGEST_LIMIT 件)、total は q に合う全件数。cat の名前は画面の I18N(mastery.cat.<キー>)
    """
    recipes, names = _need_recipes(store), store.names()
    tops = store.derived("@recipe_tops", (recipes, names), lambda: recipes.tops(names))
    cands = pick_tops(q, tops)
    return {"total": len(cands), "items": cands[:RECIPE_SUGGEST_LIMIT]}


def lookup_recipe(store: Store, key: str) -> dict:
    """要求素材集: key(できる物の内部パス)の素材を部品ごとの入れ子で返す(Recipes.view)。設計図が無ければ 404。

    末端の素材の sources = {rows: 入手先の先頭 RECIPE_SOURCE_LIMIT 件(find_sources の行。確率の高い順。コンクラーヴは sort_sources で後ろ), total: 全件数}。
    ドロップ表がまだ無ければ入手先は空(素材の一覧は出す)
    """
    recipes, names = _need_recipes(store), store.names()
    drops, src = store.drops(), store.sources()

    def sources_of(en: str) -> dict:
        rows = sort_sources(find_sources(en, drops, src, names)) if drops else []
        return {"rows": rows[:RECIPE_SOURCE_LIMIT], "total": len(rows)}

    view = recipes.view(key, names, sources_of)
    if view is None:
        raise ApiError(txt("err.recipe.none"), 404)
    return view


# (メソッド, パス) -> 処理。c はリクエスト(wfp/api/server.py の Request)
ROUTES = {
    ("GET", "/api/suggest/item"): lambda c: suggest_items(c.store, c.q.get("q", ""), parse_kinds(c.q.get("kinds"), ITEM_KIND_DEFAULT),
                                                          c.q.get("cat", ""), c.flag("noprime")),
    ("GET", "/api/item"): lambda c: lookup_item(c.store, c.q.get("key", ""), c.flag("events")),
    ("GET", "/api/suggest/area"): lambda c: suggest_areas(c.store, c.q.get("q", "")),
    ("GET", "/api/area"): lambda c: lookup_area(c.store, c.q.get("type", "planet"), c.q.get("key", ""),
                                                parse_kinds(c.q.get("kinds")), c.flag("events")),
    ("GET", "/api/suggest/enemy"): lambda c: suggest_enemies(c.store, c.q.get("q", "")),
    ("GET", "/api/suggest/recipe"): lambda c: suggest_recipes(c.store, c.q.get("q", "")),
    ("GET", "/api/recipe"): lambda c: lookup_recipe(c.store, c.q.get("key", "")),
    ("GET", "/api/enemy"): lambda c: lookup_enemy(c.store, c.q.get("name", ""), parse_kinds(c.q.get("kinds"), ENEMY_KIND_DEFAULT)),
}
