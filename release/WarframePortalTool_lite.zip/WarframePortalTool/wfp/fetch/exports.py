"""公式 Public Export の取得と名前辞書の作成・Export Plus(シンジケート・クエスト報酬・商人。オプション)の取得"""
from __future__ import annotations

import json

from wfp.core.errors import TextError, TextFailure, error_text
from wfp.core.i18n import name_txt, txt
from wfp.core.log import say
from wfp.core.const import (
    EXPORT_BASE, EXPORT_EXTRA_LANGS, EXPORT_GITHUB, EXPORT_PLUS_FILES, EXPORT_PLUS_GITHUB, EXPORT_PREFIXES, EXPORT_SRC_GITHUB,
    EXPORT_SRC_OFFICIAL, EXPORT_UNLOCALIZED,
    REGIONS_EXPORT,
)
from wfp.core.names import names_by_lang, names_from_exports
from wfp.fetch import decode, net


def fetch_export(lang: str, prefixes: tuple = EXPORT_PREFIXES) -> list[dict]:
    """公式サイトから直接取得する(予備)。prefixes で始まるファイルだけ"""
    raw = net.http_get(f"{EXPORT_BASE}/index_{lang}.txt.lzma")
    text = decode.decompress_lzma(raw).decode("utf-8", "replace")
    docs = []
    for line in text.splitlines():
        if line.startswith(prefixes):
            say(txt("log.get", file=line.split("!")[0]), 1)
            docs.append(decode.parse_export_json(net.http_get(f"{EXPORT_BASE}/Manifest/{line}").decode("utf-8", "replace")))
    return docs


def fetch_export_github(lang: str, prefixes: tuple = EXPORT_PREFIXES) -> list[dict]:
    """calamity-inc/warframe-public-export (展開済み JSON) から取得する。prefixes のファイルだけ。
    言語で中身が変わらないもの(EXPORT_UNLOCALIZED)は言語の付かないファイル名(github_file)"""
    docs = []
    for prefix in prefixes:
        name = github_file(prefix, lang)
        say(txt("log.get", file=name), 1)
        docs.append(decode.parse_export_json(net.http_get(f"{EXPORT_GITHUB}/{name}", timeout=120).decode("utf-8", "replace")))
    return docs


def github_file(prefix: str, lang: str) -> str:
    """GitHub(calamity-inc)でのファイル名。ExportRecipes など言語の無いものは「ExportRecipes.json」、ほかは「ExportWeapons_en.json」"""
    return f"{prefix}.json" if prefix in EXPORT_UNLOCALIZED else f"{prefix}_{lang}.json"


def fetch_names(docs_out: dict | None = None) -> dict:
    """名前辞書を作る。docs_out を渡すと、取得した Export (en / ja) と取得元をそこに入れる(シミュレータ用データに使う)"""
    errors = []
    for label, fetch in ((EXPORT_SRC_GITHUB, fetch_export_github), (EXPORT_SRC_OFFICIAL, fetch_export)):
        say(txt("log.source", src=name_txt("export.src.", label)), 1)
        try:
            en_docs, ja_docs = fetch("en"), fetch("ja")
            names = names_from_exports(en_docs, ja_docs)
            names["source"] = label
            if docs_out is not None:
                docs_out.update(en=en_docs, ja=ja_docs, source=label)
            return names
        except Exception as e:  # noqa: BLE001
            say(txt("log.failed", e=error_text(e)), 1)
            errors.append(txt("log.failed.what", what=name_txt("export.src.", label), e=error_text(e)))
    raise TextFailure(errors)


def fetch_lang_names(lang: str, en_docs: list[dict], first_src: str | None = None) -> tuple[dict[str, str], str]:
    """日英のほかの言語の名前辞書(英名 -> その言語の名前)を (辞書, 取得元) で返す。

    en_docs は fetch_names で取った英語版(docs_out["en"])。first_src(英語版を取れた取得元)を先に試し、だめならもう一方。
    lang は EXPORT_EXTRA_LANGS にあるものだけ(違えば TextError)。どちらもだめ・1件も突き合わなければ TextFailure
    """
    if lang not in EXPORT_EXTRA_LANGS:
        raise TextError(txt("err.update.lang_unknown", lang=lang))
    sources = ((EXPORT_SRC_GITHUB, fetch_export_github), (EXPORT_SRC_OFFICIAL, fetch_export))
    errors = []
    for label, fetch in sorted(sources, key=lambda src: src[0] != first_src):
        try:
            names = names_by_lang(en_docs, fetch(lang))
            if not names:
                raise TextFailure(txt("err.notfound", name=f"Export ({lang})"))
            return names, label
        except Exception as e:  # noqa: BLE001
            failed = txt("log.failed.what", what=name_txt("export.src.", label), e=error_text(e))
            say(failed, 1)
            errors.append(failed)
    raise TextFailure(errors)


def fetch_regions() -> tuple[dict, dict, str]:
    """ノード名用の ExportRegions を (英語版, 日本語版, 取得元) で返す。GitHub → 公式の順。どちらもだめなら RuntimeError

    名前辞書(fetch_names)とは別に取る: 一緒にすると names.json の en2ja にノード名が混ざるため
    """
    errors = []
    for label, fetch in ((EXPORT_SRC_GITHUB, fetch_export_github), (EXPORT_SRC_OFFICIAL, fetch_export)):
        try:
            en, ja = fetch("en", (REGIONS_EXPORT,)), fetch("ja", (REGIONS_EXPORT,))
            if not en or not ja:
                raise TextFailure(txt("err.notfound", name=REGIONS_EXPORT))
            return en[0], ja[0], label
        except Exception as e:  # noqa: BLE001
            failed = txt("log.failed.what", what=name_txt("export.src.", label), e=error_text(e))
            say(failed, 1)
            errors.append(failed)
    raise TextFailure(errors)


def fetch_export_plus() -> dict[str, dict]:
    """Export Plus(calamity-inc/warframe-public-export-plus)の EXPORT_PLUS_FILES を {名前: 中身} で返す。
    どれか1つでも取れない・オブジェクトでなければ TextFailure(3つそろわないと入手先が欠けるので、前回分を残す)"""
    out: dict[str, dict] = {}
    for name in EXPORT_PLUS_FILES:
        say(txt("log.get", file=f"{name}.json"), 1)
        doc = json.loads(net.http_get(f"{EXPORT_PLUS_GITHUB}/{name}.json", timeout=120).decode("utf-8", "replace"))
        if not isinstance(doc, dict):
            raise TextFailure(txt("err.notfound", name=name))
        out[name] = doc
    return out
