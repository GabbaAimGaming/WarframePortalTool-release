"""入手先の検索・候補選び"""
from __future__ import annotations

from typing import Callable

from wfp.core.common import rank
from wfp.core.i18n import name_txt, render_ja, txt
from wfp.core.text import norm
from wfp.core.const import AREA_KIND_DEFAULT, AREA_KINDS, SOURCE_CATS
from wfp.core.names import Names, item_key
from wfp.drops.tables import DropRow, Drops, Sources, Vault, mission_place, stage_label


def find_sources(key: str, drops: Drops | None, sources: Sources | None, names: Names, events: bool = False,
                 vault: Vault | None = None) -> list[dict]:
    """項目(英名)の入手先を、ミッション・敵・バウンティ・レリック・クラン研究等すべてから集めて確率の高い順に返す(確率の無いクラン研究は最後)。

    cat は入手先の種類のキー(SOURCE_CATS)、敵の行だけ enemy に敵の英名(敵から探すへのリンク用)、rarity はレア度のキー(Common など)、place・detail・stage はテキスト指定。
    vault を渡すと、Vault 入り(いまは出ない)レリックの行に vaulted: True を付ける
    (wfp/core/i18n.py の txt。画面は web/i18n の表で、CLI は render_ja で文にする)。並びは日本語の入手先名で決める。
    Prime Resurgence の期間の内(vault.resurgence)なら、交換できるレリックの行に resurgence: 期限(UNIX 時刻)を付け、
    項目がそのレリック自体なら入手先「Prime Resurgence」の行(cat resurgence・until に期限)を足す。
    drops が None(ドロップ表がまだ無い)なら sources の行だけ
    """
    k = item_key(key)
    out = []
    for planet, node, mode, event, rot, item, chance, rarity in (drops.rows if drops else []):
        if item_key(item) == k and (events or not event):
            out.append({"cat": "mission", "place": mission_place(planet, node), "detail": name_txt("mode.", mode), "event": event,
                        "stage": stage_label(rot), "qty": names.split_qty(item)[0], "chance": chance, "rarity": rarity})
    for r in (sources.rows if sources else []):
        if item_key(r.item) == k:
            row = {"cat": r.cat, "place": r.place, "detail": r.detail, "event": False,
                   "stage": stage_label(r.rot), "qty": names.split_qty(r.item)[0], "chance": r.chance, "rarity": r.rarity}
            if r.cat == "enemy":
                row["enemy"] = r.place  # 敵の英名(画面はここから敵から探すへ移る)
            if vault is not None and r.relic and vault.relic_vaulted(r.relic):
                row["vaulted"] = True
            elif vault is not None and r.relic and vault.relic_offered(r.relic):
                row["resurgence"] = vault.until
            out.append(row)
    if vault is not None and vault.relic_offered(key):
        out.append(_resurgence_row(vault))
    order = {c: i for i, c in enumerate(SOURCE_CATS)}
    # 確率の無い入手先(クラン研究)は確率のある行のあと
    out.sort(key=lambda r: (r["chance"] is None, -(r["chance"] or 0), order.get(r["cat"], 99), render_ja(r["place"])))
    return out


def _resurgence_row(vault: Vault) -> dict:
    """レリック自体の入手先「Prime Resurgence」の行(アヤで交換。確率は無い。until は期限)"""
    return {"cat": "resurgence", "place": txt("src.resurgence.place"), "detail": txt("src.resurgence.detail"), "event": False,
            "stage": stage_label("-"), "qty": "", "chance": None, "rarity": "", "until": vault.until}


def source_index(drops: Drops | None, sources: Sources | None) -> dict[str, list[tuple]]:
    """項目ごとの入手先: {item_key: [(種類, 入手先, 詳細, 段, 確率)]}。イベントの行は入れない。
    入手先・詳細・段はテキスト指定、確率は無ければ None(クラン研究・商人など)。一覧の集計(source_brief)に使う"""
    idx: dict[str, list[tuple]] = {}
    for planet, node, mode, event, rot, item, chance, rarity in (drops.rows if drops else []):
        if not event:
            idx.setdefault(item_key(item), []).append(
                ("mission", mission_place(planet, node), name_txt("mode.", mode), stage_label(rot), chance))
    for r in (sources.rows if sources else []):
        idx.setdefault(item_key(r.item), []).append((r.cat, r.place, r.detail, stage_label(r.rot), r.chance))
    return idx


def source_brief(src: list[tuple]) -> dict:
    """source_index の1項目分を、種類ごとの件数(SOURCE_CATS の順)・件数・もっとも確率の高い入手先にまとめる。
    確率の無い入手先(クラン研究・商人など)は確率のあるものより後(それしか無ければそれ)"""
    counts: dict[str, int] = {}
    for s in src:
        counts[s[0]] = counts.get(s[0], 0) + 1
    best = max(src, key=lambda s: -1 if s[4] is None else s[4]) if src else None
    return {"counts": {c: counts[c] for c in SOURCE_CATS if c in counts}, "total": len(src),
            "best": {"cat": best[0], "place": best[1], "detail": best[2],
                     "stage": best[3], "chance": best[4]} if best else None}


def all_item_names(drops: Drops, sources: Sources | None, extra: list[str] | tuple = ()) -> list[str]:
    """候補になる項目の英名。extra はドロップ表に無いが入手先がある項目(いま Prime Resurgence で交換できるレリック)"""
    return sorted(set(drops.item_names) | set(sources.item_names if sources else []) | set(extra))


def parts_by_owner(items, names: Names, owners: dict[str, str] | None = None) -> dict[str, list[str]]:
    """本体ごとのパーツ: {本体の英名を norm したもの: [パーツの英名]}。items は all_item_names の項目。
    パーツ → 本体は Names.part_of(owners は Sources.part_owner。設計図ではない作成素材も入る)。
    数量違い・大文字小文字違いは item_key で1つに束ねる(group_candidates と同じ。最初に出た綴りを残す。find_sources も item_key で
    照合するので、どちらの綴りでも入手先は同じ)。本体と同じ名前の項目(本体そのもの)は除く・名前順"""
    out: dict[str, dict[str, str]] = {}
    for n in sorted(items):
        if hit := names.part_of(n, owners):
            key, part = norm(hit[0]), names.split_qty(n)[1]
            if norm(part) != key:
                out.setdefault(key, {}).setdefault(item_key(part), part)
    return {k: sorted(v.values()) for k, v in out.items()}


def part_sources(parts: list[str], drops: "Drops", sources: Sources | None, names: Names,
                 vault: Vault | None = None, events: bool = False) -> list[dict]:
    """パーツごとの入手先: [{en, ja, vaulted, rows}]。parts は parts_by_owner で引いた本体のパーツ。入手先の無いパーツは入れない。
    rows は find_sources の行。vaulted は入手先が Vault 入りのレリックだけ(いま手に入らない。vault を渡したときだけ)"""
    out = []
    for part in parts:
        rows = find_sources(part, drops, sources, names, events=events, vault=vault)
        if rows:
            out.append({"en": part, "ja": names.ja(part), "vaulted": bool(vault is not None and vault.unavailable(part)), "rows": rows})
    return out


def pick_candidates(query: str, item_names, names: Names, materials_only: bool = False,
                    keep: Callable[[str], bool] | None = None) -> list[str]:
    """名前(英名・日本語名・ひらがな)が query に合う項目を、合い方の良い順に返す。
    materials_only は素材だけに絞る。keep を渡すと、それが True を返す項目だけに絞る(パーツ検索など)"""
    if isinstance(item_names, Drops):  # 以前の呼び方 (ドロップ表を直接渡す) にも対応
        item_names = item_names.item_names
    scored = []
    for n in item_names:
        if (materials_only and not names.is_resource(n)) or (keep is not None and not keep(n)):
            continue
        r = rank(query, [n, names.ja(n), names.split_qty(n)[1]])
        if r is not None:
            scored.append((r, norm(names.ja(n)), n))
    scored.sort()
    return [n for _, _, n in scored]


def group_candidates(cands: list[str], names: Names) -> dict[str, str]:
    """候補を数量違い・大文字小文字違いで束ねる -> {キー: 表示に使う英名}"""
    groups: dict[str, str] = {}
    for n in cands:
        groups.setdefault(item_key(n), names.split_qty(n)[1])
    return groups


def area_stages(rows: list[DropRow], names: Names, kinds: set[str]) -> dict[str, list[tuple[DropRow, str]]]:
    """エリア検索: 1ノードのドロップ行(Drops.node_rows)をローテーションごとに分け、{ローテーション: [(行, 種類)]} で返す。

    kinds は出す種類(AREA_KINDS のキー)の集まり。並びは種類の順(AREA_KINDS の順)→ 確率の高い順。知らないキーは無視する
    """
    order = list(AREA_KINDS)
    out: dict[str, list[tuple[DropRow, str]]] = {}
    for row in rows:
        kind = names.item_kind(row.item)
        if kind in kinds:
            out.setdefault(row.rot, []).append((row, kind))
    for lst in out.values():
        lst.sort(key=lambda pair: (order.index(pair[1]), -pair[0].chance))
    return dict(sorted(out.items()))


def parse_kinds(raw: object, default: tuple[str, ...] = AREA_KIND_DEFAULT) -> set[str]:
    """画面から来た種類の指定("resource,part" など)を AREA_KINDS のキーの集まりにする。None(指定なし)なら default"""
    if raw is None:
        return set(default)
    return {k for k in str(raw).split(",") if k in AREA_KINDS}


def pick_enemies(query: str, enemies: list[str]) -> list[str]:
    """敵の名前(英名)が query に合うものを、合い方の良い順(同じなら名前順)に返す。query が空なら何も返さない(敵は千件以上あるため)"""
    scored = [(r, norm(n), n) for n in enemies if (r := rank(query, [n])) is not None]
    scored.sort()
    return [n for _, _, n in scored]


def enemy_drops(enemy: str, sources: Sources | None, names: Names, kinds: set[str]) -> list[dict]:
    """敵から探す: 1体の敵が落とすアイテム(Sources の enemy の行)を返す。

    kinds は出す種類(AREA_KINDS のキー)の集まり。並びは種類の順(AREA_KINDS の順)→ 確率の高い順 → 英名。
    同じアイテムでも表(素材・MOD・設計図など)が違えば別の行。detail は表のテキスト指定、chance は1体倒したときに落とす割合(%)、
    kind は種類のキー、qty は数量(無ければ "")、rarity はレア度のキー
    """
    order = list(AREA_KINDS)
    owners = sources.part_owner if sources else {}
    out = []
    for r in (sources.rows if sources else []):
        if r.cat != "enemy" or r.place != enemy:
            continue
        kind = names.item_kind(r.item, owners)
        if kind not in kinds:
            continue
        qty, base = names.split_qty(r.item)
        out.append({"en": base, "ja": names.ja(base), "kind": kind, "detail": r.detail, "qty": qty,
                    "chance": r.chance, "rarity": r.rarity})
    out.sort(key=lambda r: (order.index(r["kind"]), -(r["chance"] or 0), r["en"].lower()))
    return out
