#!/usr/bin/env python3
"""wfportal_ocr - ビルド画像の自動解析 (Windows 標準の文字認識 + 名前一覧との照合 / 標準ライブラリのみ)

流れ:
  1. 文字認識のエンジン(wfp/ocr。今は Windows OCR = ocr/winocr.ps1)で、文字と位置(行・単語ごとの枠)を受け取る
  2. 読み取った文字を、公式の名前一覧(MOD・アルケイン・フレーム/武器)と照合して読み間違いを補正する
       - 単語の並びを少しずつずらして候補を作る(長い MOD 名が2行に折り返す場合も1つにまとめる)
  3. 結果から次を求める
       - 対象(フレーム・武器): 名前一覧に一致する中で、いちばん大きい文字
       - MOD: 画面上の並び(上の段から、左から順)
       - フォーマ数: 画面に「フォーマ 3」などの表示があればその値。無ければ、各 MOD カードのドレイン(消費
         キャパシティ)から極性が一致しているスロットを数えて推定する(一致すると消費が半分になるため)

文字認識を呼ぶのは wfp/ocr(2026-11-20 に分けた)。使えない環境では wfp.ocr.engine の OcrUnavailable。解析(2〜3)は OCR の結果(JSON)
さえあればどこでも動くので、テストや不具合報告の再現に使える。
"""
from __future__ import annotations

import json
import math
import re
import sys
from pathlib import Path

from wfp.core.i18n import txt
from wfp.core.const import BUILD_TYPES, OCR_ENGINE_AUTO, OCR_LANG_MULTI, POLARITY_EN
from wfp.core.loader import load_names
from wfp.core.matcher import NameMatcher
from wfp.core.names import Names
from wfp.core.text import ocr_key
from wfp.ocr.engine import OcrUnavailable, run_ocr_bytes
from wfp.ocr.result import pick_result


# 解析の調整(値は 2026-11-17 の分け直しの前と同じ)。位置・大きさは MOD 名の文字の高さ h やカードの間隔に対する倍率
# 画面全体の読み取り
BLD_OCR_WEIGHT_POWER = 4      # 重なった候補の選び方: 長い名前 × 一致度 ** これ(一致度を強めに効かせる)
BLD_OCR_INV_MARGIN = 2        # 所持 MOD 一覧(検索欄)の少し上(px)までを装備中として残す
BLD_OCR_FORMA_MAX = 40        # 画面の「フォーマ N」として受け付ける数の上限
# MOD のカードの読み取り
MOD_OCR_ROW_GAP = 2.5         # 名前の縦の中心がこれ × h より離れたら次の段
MOD_OCR_DRAIN_MAX = 30        # ドレインとして受け付ける数の上限
MOD_OCR_PITCH_X = 16          # カードの横の間隔の予備(× h。となりの MOD 名が無いとき)
MOD_OCR_PITCH_Y = 12          # 段の間隔の予備(× h。段が1つのとき)
MOD_OCR_DRAIN_SPAN_X = 0.6    # ドレインを探す範囲: 左右はカードの間隔のこの割合まで
MOD_OCR_DRAIN_SPAN_UP = 0.9   # 上は段の間隔のこの割合まで
MOD_OCR_DRAIN_SPAN_DOWN = 0.5  # 下は名前の高さのこの割合まで
# ゲームの MOD 一覧(コーデックス)の読み取り(2026-11-23。MOD 入手一覧の画面共有・スクリーンショット)
MOD_SCAN_LIT_MIN = 160        # 名前の文字のいちばん明るい画素(RGB の最大)がこれ以上なら取得済み。未取得のカードは暗い
                              # (実測: 取得済み 221〜253(強化の有無・枠の色によらない)・未取得 101)
MOD_SCAN_HEAD_LETTERS = 3     # 英字が全部大文字でこの数以上なら見出し(「入手先 - FLAME GLAND」)。カードの名前は大文字小文字が混ざる


# --------------------------------------------------------------------------
# 2. 名前一覧との照合
# --------------------------------------------------------------------------

def build_matcher(names: Names) -> NameMatcher:
    # コンクレーヴ専用の MOD は照合しない(普通の MOD の読み違いが当たらないように。2026-11-23)
    entries = [("mod", m["en"], m) for m in names.mods if not m.get("conclave")]
    entries += [("arcane", a, None) for a in names.arcanes]
    entries += [("item", it["en"], it) for it in names.items]
    m = NameMatcher(entries)
    # 日本語版ではアルケイン名だけ日本語で表示される(例: アルケイン エナージャイズ)。日本語の読み取り結果と照合する
    m.ja = NameMatcher([("arcane", names.ja(a), a) for a in names.arcanes if names.ja(a) != a])
    return m


# --------------------------------------------------------------------------
# 3. 解析
# --------------------------------------------------------------------------

def _box(words: list[dict]) -> tuple[float, float, float, float]:
    x0 = min(w["x"] for w in words)
    y0 = min(w["y"] for w in words)
    x1 = max(w["x"] + w["w"] for w in words)
    y1 = max(w["y"] + w["h"] for w in words)
    return x0, y0, x1 - x0, y1 - y0


def _median(v: list[float], default: float = 10.0) -> float:
    v = sorted(v)
    return v[len(v) // 2] if v else default


def _split_slash(w: dict) -> list[dict]:
    """「アップグレード/NOVA」のように / でつながった単語を分ける(位置は文字数で按分)"""
    t = w["text"]
    if "/" not in t.strip("/"):
        return [w]
    parts, out, pos = t.split("/"), [], 0
    per = w["w"] / max(len(t), 1)
    for part in parts:
        if part.strip():
            out.append({**w, "text": part, "x": w["x"] + pos * per, "w": len(part) * per})
        pos += len(part) + 1
    return out


def _segments(lines: list[dict]) -> list[list[dict]]:
    """1行の中でも大きく離れた単語は別の塊にする(となりの MOD カードの名前が同じ行に並ぶため)"""
    segs = []
    for line in lines:
        words = sorted((p for w in line.get("words", []) if w.get("text", "").strip() for p in _split_slash(w)), key=lambda w: w["x"])
        if not words:
            continue
        h = _median([w["h"] for w in words])
        cur = [words[0]]
        for w in words[1:]:
            gap = w["x"] - (cur[-1]["x"] + cur[-1]["w"])
            if gap > 1.1 * h:
                segs.append(cur)
                cur = [w]
            else:
                cur.append(w)
        segs.append(cur)
    return segs


def _candidates(segs: list[list[dict]]):
    """照合する候補: 各塊の連続する単語(最大6語)と、真下に折り返した2行の組み合わせ"""
    for si, seg in enumerate(segs):
        for i in range(len(seg)):
            for j in range(i + 1, min(len(seg), i + 6) + 1):
                ws = seg[i:j]
                yield " ".join(w["text"] for w in ws), ws
    boxes = [_box(s) for s in segs]
    for a, (ax, ay, aw, ah) in enumerate(boxes):
        for b, (bx, by, bw, bh) in enumerate(boxes):
            if a == b or not (0.7 < bh / max(ah, 1) < 1.4):
                continue
            gap = by - (ay + ah)
            if -0.3 * ah <= gap <= 1.0 * ah and abs((ax + aw / 2) - (bx + bw / 2)) < 0.6 * max(aw, bw):
                ws = segs[a] + segs[b]
                yield " ".join(w["text"] for w in ws), ws


_DIGIT_FIX = str.maketrans({"O": "0", "o": "0", "D": "0", "l": "1", "I": "1", "|": "1", "S": "5", "B": "8"})


def _number(text: str) -> int | None:
    """1〜2 桁の数字。ドレイン表示の "^14" "7—" "8Y" のように、極性の記号がくっついていても読む"""
    t = text.strip()
    m = re.fullmatch(r"[^\w]{0,2}([0-9OoDlI|SB]{1,2})[^\d]{0,2}", t)
    if not m:
        return None
    d = m.group(1).translate(_DIGIT_FIX)
    return int(d) if d.isdigit() else None


def _inventory_top(results: list[dict]) -> float | None:
    """画面下半分の「所持 MOD 一覧」の始まり(検索欄の位置)。これより下の MOD はビルドに含めない"""
    ys = []
    for r in results:
        for line in r.get("lines") or []:
            text = line.get("text", "").replace(" ", "")
            if (text.startswith("検索") or re.match(r"(?i)^search", text)) and line.get("words"):
                ys.append(_box(line["words"])[1])
    return min(ys) if ys else None


_RANK_RE = re.compile(r"^[\[(|lI]?\s*([0-9OoDlI]{1,2})\s*[\])|lI1]?$")


def read_header_forma(results: list[dict], anchor: tuple | None) -> dict | None:
    """画面上部「アップグレード/NOVA PRIME [30] (アイコン) (アイコン) 6」の最後の数字(フォーマ数)を読む。

    anchor: 装備名の枠 (x, y, w, h)。無ければ「アップグレード / UPGRADE」の行を探す。
    装備名の右側・同じ高さにある文字を左から見て、ランク([30] など)の次に来る 1〜2 桁の数字を採る。
    右上の所持金(48,012,058 など)はカンマ付き・桁が多いので拾わない。
    """
    if anchor is None:
        for r in results:
            for line in r.get("lines") or []:
                ws = line.get("words") or []
                for i, w in enumerate(ws):
                    if "アップグレード" in w.get("text", "") or re.search(r"(?i)upgrade", w.get("text", "")):
                        x, y, ww, hh = _box(ws)
                        anchor = (w["x"], y, w["w"], hh)
                        break
                if anchor:
                    break
            if anchor:
                break
    if anchor is None:
        return None
    ax, ay, aw, ah = anchor
    cy = ay + ah / 2
    for r in results:
        row = []
        for line in r.get("lines") or []:
            for w in line.get("words") or []:
                wcy = w["y"] + w["h"] / 2
                if abs(wcy - cy) <= 0.6 * ah and w["x"] >= ax + aw - 0.2 * ah:
                    row.append(w)
        row.sort(key=lambda w: w["x"])
        rank_end = None
        for w in row:
            t = w["text"].replace(" ", "")
            if rank_end is None:
                # "[30]" が "[", "30", "]" に分かれることもある
                m = _RANK_RE.match(t)
                if m and m.group(1).translate(_DIGIT_FIX).isdigit() and 0 <= int(m.group(1).translate(_DIGIT_FIX)) <= 40:
                    rank_end = w["x"] + w["w"]
                    rank = int(m.group(1).translate(_DIGIT_FIX))
                continue
            if t in ("]", ")", "|"):
                rank_end = w["x"] + w["w"]
                continue
            if w["x"] - rank_end > 8 * ah:
                break  # 離れすぎ(右上の所持金など)
            if "," in t or len(re.sub(r"\D", "", t)) > 2:
                break
            n = _number(t) if len(t) <= 4 else None
            if n is not None:
                return {"value": n, "rank": rank, "read": t, "lang": r.get("lang")}
    return None


def _drain_status(m: dict, shown: int) -> str | None:
    """MOD が最大ランクとして、表示されたドレインからスロットの極性の状態を判定する"""
    base, rank = m.get("drain"), m.get("max_rank")
    if base is None or rank is None or m.get("type") in ("AURA", "STANCE"):
        return None  # オーラ・スタンスはキャパシティを増やす側なので判定しない
    full = int(base) + int(rank)
    if full <= 0:
        return None
    half = math.floor(full / 2 + 0.5)
    more = math.floor(full * 1.25 + 0.5)
    if shown == half:
        return "match"
    if shown == full:
        return "neutral"
    if shown == more:
        return "mismatch"
    return None


FORMA_PATTERNS = [
    r"フォーマ\s*[x×:：]?\s*(\d{1,2})", r"(\d{1,2})\s*[x×]?\s*回?\s*フォーマ",
    r"forma(?:ed)?\s*[x×:]?\s*(\d{1,2})", r"(\d{1,2})\s*[x×]\s*forma", r"polari[sz]ed\s*[x×:]?\s*(\d{1,2})",
]


def _center_x(box: tuple) -> float:
    """箱(x, y, w, h)の横の中心"""
    return box[0] + box[2] / 2


def _center_y(box: tuple) -> float:
    """箱(x, y, w, h)の縦の中心"""
    return box[1] + box[3] / 2


def _tag_words(lines: list[dict], prefix: tuple = ()) -> None:
    """単語に番号 _id(prefix + 行・単語の位置)を振る(候補の重なり・使った数字の印に使う)"""
    for i, line in enumerate(lines):
        for j, w in enumerate(line.get("words", [])):
            w["_id"] = (*prefix, i, j)


def _candidate(kind: str, name: str, info, score: float, text: str, ws: list[dict], key: str) -> dict:
    """照合に当たった候補1つ(weight は重なったときに選ぶ重み = 長い名前 × 一致度)"""
    return {"kind": kind, "name": name, "info": info, "score": score, "text": text,
            "ids": {w["_id"] for w in ws}, "box": _box(ws), "weight": len(key) * score ** BLD_OCR_WEIGHT_POWER}


def _ja_lines(results: list[dict], main: dict) -> list[dict] | None:
    """アルケイン名(日本語)を探す行。日本語の結果が別にあればその行(単語の印を付け直す)、
    日英を1回で読んだ結果(mul)ならその行のまま、どちらでもなければ None"""
    if str(main.get("lang", "")).lower() == OCR_LANG_MULTI:
        return main.get("lines") or []
    ja_res = pick_result(results, "ja")
    if not ja_res or ja_res is main:
        return None
    lines = ja_res.get("lines") or []
    _tag_words(lines, ("ja",))
    return lines


def _match_candidates(results: list[dict], main: dict, lines: list[dict], matcher: NameMatcher) -> list[dict]:
    """名前の候補を集める: 英語の結果で名前一覧と照合し、日本語の結果があればアルケイン名も探す"""
    found = []
    for text, ws in _candidates(_segments(lines)):
        hit = matcher.match(text)
        if hit:
            score, kind, name, info, key = hit
            found.append(_candidate(kind, name, info, score, text, ws, key))
    ja_matcher = getattr(matcher, "ja", None)
    ja_lines = _ja_lines(results, main) if ja_matcher else None
    if ja_lines is not None:
        for text, ws in _candidates(_segments(ja_lines)):
            hit = ja_matcher.match(text)
            if hit:
                score, _kind, _ja, en_name, key = hit
                found.append(_candidate("arcane", en_name, None, score, text, ws, key))
    return found


def _pick_non_overlapping(found: list[dict]) -> tuple[list[dict], set]:
    """重なる候補は重みの大きい方を採る(例: "Primed Continuity" と "Continuity")。(選んだ候補, 使った単語の _id)"""
    found.sort(key=lambda f: -f["weight"])
    used: set = set()
    picked, arc_seen = [], set()
    for f in found:
        if f["ids"] & used:
            continue
        if f["kind"] == "arcane":  # 英語と日本語の両方で読めた場合は1つにまとめる
            if f["name"].lower() in arc_seen:
                continue
            arc_seen.add(f["name"].lower())
        used |= f["ids"]
        picked.append(f)
    return picked, used


def _drop_inventory(picked: list[dict], results: list[dict]) -> list[dict]:
    """画面下半分の所持 MOD 一覧(検索欄より下)は、装備中の MOD ではないので除く(装備名は残す)"""
    inv_top = _inventory_top(results)
    if inv_top is None:
        return picked
    return [f for f in picked if f["kind"] == "item" or f["box"][1] < inv_top - BLD_OCR_INV_MARGIN]


def _pick_target(picked: list[dict]) -> dict | None:
    """対象: 名前一覧の装備に一致する中で、いちばん大きい文字"""
    items = [f for f in picked if f["kind"] == "item"]
    return max(items, key=lambda f: (f["box"][3] * (0.5 + f["score"] / 2), f["score"]), default=None)


def _order_rows(picked: list[dict]) -> tuple[list[list[dict]], list[dict], float]:
    """MOD・アルケインを上の段から、左から順に並べる。(段ごとの一覧, 並べた一覧, 名前の文字の高さの中央値)"""
    mods = [f for f in picked if f["kind"] in ("mod", "arcane")]
    h = _median([f["box"][3] for f in mods])
    mods.sort(key=lambda f: _center_y(f["box"]))
    rows, row_y = [], None
    for f in mods:
        cy = _center_y(f["box"])
        if row_y is None or cy - row_y > MOD_OCR_ROW_GAP * h:
            rows.append([])
            row_y = cy
        rows[-1].append(f)
    return rows, [f for row in rows for f in sorted(row, key=lambda f: f["box"][0])], h


def _drain_numbers(lines: list[dict], used: set) -> list[tuple[int, dict]]:
    """ドレインの数字の候補: 名前に使っていない、1〜MOD_OCR_DRAIN_MAX の数の単語"""
    numbers = []
    for line in lines:
        for w in line.get("words", []):
            n = _number(w.get("text", ""))
            if n is not None and 0 < n <= MOD_OCR_DRAIN_MAX and w["_id"] not in used:
                numbers.append((n, w))
    return numbers


def _assign_drains(mods: list[dict], rows: list[list[dict]], numbers: list[tuple[int, dict]], h: float) -> None:
    """ドレイン(カード右上の数字)を各 MOD に対応づける(f["drain"] f["slot"] を足す)。一致度の高い MOD から、
    自分のカードの範囲にあるいちばん近い数字を取る。カードの幅と段の間隔は、となり合う MOD 名の間隔から見積もる(画面の解像度によらない)"""
    cxs = lambda row: sorted(_center_x(f["box"]) for f in row if f["kind"] == "mod")
    pitch_x = _median([b - a for row in rows for a, b in zip(cxs(row), cxs(row)[1:])], MOD_OCR_PITCH_X * h)
    row_cy = [_median([_center_y(f["box"]) for f in row]) for row in rows]
    pitch_y = _median([b - a for a, b in zip(row_cy, row_cy[1:])], MOD_OCR_PITCH_Y * h)
    taken = set()
    for f in sorted(mods, key=lambda f: -f["score"]):
        if f["kind"] != "mod":
            continue
        cx, cy, name_h = _center_x(f["box"]), _center_y(f["box"]), f["box"][3]
        best = None
        for n, w in numbers:
            if w["_id"] in taken:
                continue
            dx = (w["x"] + w["w"] / 2) - cx
            dy = (w["y"] + w["h"] / 2) - cy
            if abs(dx) > MOD_OCR_DRAIN_SPAN_X * pitch_x or not (-MOD_OCR_DRAIN_SPAN_UP * pitch_y <= dy <= MOD_OCR_DRAIN_SPAN_DOWN * name_h):
                continue
            dist = math.hypot(dx / pitch_x, dy / pitch_y)
            if best is None or dist < best[0]:
                best = (dist, n, w)
        if best:
            taken.add(best[2]["_id"])
            f["drain"] = best[1]
            f["slot"] = _drain_status(f["info"], best[1])


def _mod_out(mods: list[dict], names: Names) -> list[dict]:
    """MOD・アルケインの結果の形(英名・和名・種類・一致度・読んだ文字・種別・極性・ドレイン・スロットの状態)"""
    out = []
    for f in mods:
        info = f["info"] or {}
        pol = info.get("polarity", "")
        out.append({
            "en": f["name"], "ja": names.ja(f["name"]), "kind": f["kind"], "score": round(f["score"], 3),
            "read": f["text"], "type": info.get("type", ""), "polarity": POLARITY_EN.get(pol, pol) if pol else "",
            "drain": f.get("drain"), "slot": f.get("slot"), "box": [round(v, 1) for v in f["box"]],
        })
    return out


def _read_forma(results: list[dict], target: dict | None, out_mods: list[dict]) -> dict:
    """フォーマ数: 画面上部の「装備名 [ランク] (アイコン) 数字」 -> 「フォーマ 3」などの表示 -> ドレインから推定"""
    forma = {"value": None, "source": None, "estimate": None, "polarized": []}
    head = read_header_forma(results, target["box"] if target else None)
    if head:
        forma.update(value=head["value"], source="display", read=head["read"], rank=head["rank"])
    all_text = " ".join(l.get("text", "") for r in results for l in (r.get("lines") or []))
    for pat in ([] if head else FORMA_PATTERNS):
        mt = re.search(pat, all_text, flags=re.I)
        if mt and 0 <= int(mt.group(1)) <= BLD_OCR_FORMA_MAX:
            forma.update(value=int(mt.group(1)), source="display", read=mt.group(0))
            break
    polarized = [m["polarity"] for m in out_mods if m["slot"] == "match" and m["polarity"]]
    if any(m["slot"] for m in out_mods):
        forma["estimate"] = len(polarized)
        forma["polarized"] = polarized
        if forma["value"] is None:
            forma.update(value=len(polarized), source="estimate")
    return forma


def _target_out(target: dict | None, names: Names) -> dict | None:
    """対象の結果の形(英名・和名・種別・一致度・読んだ文字)"""
    if not target:
        return None
    return {"en": target["name"], "ja": names.ja(target["name"]), "type": (target["info"] or {}).get("type", "other"),
            "score": round(target["score"], 3), "read": target["text"]}


def analyze(ocr: dict, names: Names, matcher: NameMatcher | None = None) -> dict:
    """OCR の結果(winocr.ps1 の JSON)から、対象・MOD・フォーマ数を求める(段ごとの関数を順に呼ぶ)"""
    matcher = matcher or build_matcher(names)
    results = ocr.get("results") or []
    # 英語の結果で名前を照合する(無ければ最初の言語)
    main = pick_result(results, "en") or (results[0] if results else {"lines": []})
    lines = main.get("lines") or []
    _tag_words(lines)
    picked, used = _pick_non_overlapping(_match_candidates(results, main, lines, matcher))
    picked = _drop_inventory(picked, results)
    target = _pick_target(picked)
    rows, mods, h = _order_rows(picked)
    _assign_drains(mods, rows, _drain_numbers(lines, used), h)
    out_mods = _mod_out(mods, names)
    return {"target": _target_out(target, names), "mods": out_mods, "forma": _read_forma(results, target, out_mods),
            "lines": [l.get("text", "") for l in lines], "langs": [r.get("lang") for r in results]}


def is_heading(read: str) -> bool:
    """読んだ文字が全部大文字の見出しか(コーデックスの「入手先 - 名前」。カードの名前は大文字小文字が混ざる)"""
    letters = [ch for ch in read if ch.isascii() and ch.isalpha()]
    return len(letters) >= MOD_SCAN_HEAD_LETTERS and all(ch.isupper() for ch in letters)


def mod_lit(png, box) -> bool | None:
    """名前の文字が明るいか(取得済みのカード)。png は pixel(x, y) -> (r, g, b)(範囲外は None)を持つもの。
    画像・枠が無い・枠が画像の外なら None(判定できない)"""
    if png is None or not box:
        return None
    left, top, width, height = (int(round(v)) for v in box)
    brightest = -1
    for py in range(top, top + height):
        for px in range(left, left + width):
            rgb = png.pixel(px, py)
            if rgb:
                brightest = max(brightest, *rgb)
    return None if brightest < 0 else brightest >= MOD_SCAN_LIT_MIN


def scan_marks(mods: list[dict], png) -> list[dict]:
    """MOD 一覧の読み取りの結果: 見出しを除き、取得済みか(lit。判定できなければ None)を付ける"""
    return [{**m, "lit": mod_lit(png, m.get("box"))} for m in mods if not is_heading(m.get("read", ""))]


def merge(analyses: list[dict]) -> dict:
    """複数の画像(MOD 画面とアルケイン画面など)の結果をまとめる"""
    targets = [a["target"] for a in analyses if a.get("target")]
    target = max(targets, key=lambda t: t["score"], default=None)
    mods, seen = [], set()
    for a in analyses:
        for m in a.get("mods", []):
            if m["en"].lower() not in seen:
                seen.add(m["en"].lower())
                mods.append(m)
    shown = [a["forma"]["value"] for a in analyses if a["forma"].get("source") == "display"]
    polarized = [p for m in mods if m["slot"] == "match" and m["polarity"] for p in [m["polarity"]]]
    judged = any(m["slot"] for m in mods)
    if shown:
        disp = max((a for a in analyses if a["forma"].get("source") == "display"), key=lambda a: a["forma"]["value"])
        forma = {"value": max(shown), "source": "display", "rank": disp["forma"].get("rank"),
                 "estimate": len(polarized) if judged else None, "polarized": polarized}
    elif judged:
        forma = {"value": len(polarized), "source": "estimate", "estimate": len(polarized), "polarized": polarized}
    else:
        forma = {"value": None, "source": None, "estimate": None, "polarized": []}
    return {"target": target, "mods": mods, "forma": forma, "images": len(analyses)}


def polarity_summary(polarized: list[str]) -> str:
    counts: dict[str, int] = {}
    for p in polarized:
        counts[p] = counts.get(p, 0) + 1
    return ", ".join(f"{p}×{n}" for p, n in sorted(counts.items(), key=lambda x: (-x[1], x[0])))


# --------------------------------------------------------------------------
# コマンドライン: python wfportal.py build analyze 画像 ... から呼ばれる
# --------------------------------------------------------------------------

def print_analysis(r: dict) -> None:
    t = r.get("target")
    print(f"対象   : {t['ja']} ({t['en']}) [{BUILD_TYPES.get(t['type'], t['type'])}] 一致度 {t['score']:.0%}" if t else "対象   : 読み取れませんでした")
    f = r["forma"]
    if f["value"] is None:
        print("フォーマ: 読み取れませんでした")
    else:
        how = (f"ゲーム内の表示: 装備名 [{f['rank']}] の後ろの数字" if f.get("rank") is not None else "ゲーム内の表示") \
            if f["source"] == "display" else "推定(極性が一致しているスロットの数)"
        print(f"フォーマ: {f['value']}  ({how})")
    if f.get("polarized"):
        print(f"極性    : {polarity_summary(f['polarized'])}  (MOD が最大ランクの前提で、ドレインから判定)")
    arcs = [m for m in r["mods"] if m["kind"] == "arcane"]
    if arcs:
        print("アルケイン: " + ", ".join(m["en"] for m in arcs))
    print(f"MOD    : {len(r['mods']) - len(arcs)} 件")
    mark = {"match": "極性一致", "neutral": "極性なし", "mismatch": "極性不一致"}
    for i, m in enumerate([m for m in r["mods"] if m["kind"] != "arcane"], 1):
        extra = [m["polarity"]] if m["polarity"] else []
        if m.get("drain") is not None:
            extra.append(f"ドレイン {m['drain']}" + (f" = {mark[m['slot']]}" if m.get("slot") else ""))
        if m["score"] < 1:
            extra.append(f"一致度 {m['score']:.0%} / 読み取り「{m['read']}」")
        print(f"  {i:>2}. {m['ja']}" + (f"  ({' / '.join(extra)})" if extra else ""))


def main_analyze(paths: list[str], data_dir: Path, raw: bool = False, save_ocr: str | None = None, ocr_json: str | None = None,
                 engine: str = OCR_ENGINE_AUTO) -> None:
    names = load_names(data_dir)
    if not names.mods:
        sys.exit("MOD の情報がありません。先に `python wfportal.py update` を実行してください。")
    matcher = build_matcher(names)
    analyses, dumps = [], []
    sources = [("json", p) for p in ([ocr_json] if ocr_json else [])] + [("img", p) for p in paths]
    if not sources:
        sys.exit("画像ファイルを指定してください。")
    for kind, p in sources:
        try:
            if kind == "json":
                ocr = json.loads(Path(p).read_text(encoding="utf-8-sig"))
                ocr = ocr if isinstance(ocr, list) else [ocr]
            else:
                ocr = [run_ocr_bytes(Path(p).expanduser().read_bytes(), pref=engine)]
        except OcrUnavailable as e:
            sys.exit(str(e))
        except (OSError, ValueError) as e:
            sys.exit(f"{p} を読めませんでした: {e}")
        for o in ocr:
            dumps.append(o)
            if raw:
                for r in o.get("results", []):
                    print(f"--- {p} [{r.get('lang')}] ---")
                    for line in r.get("lines", []):
                        print("  " + line.get("text", ""))
            analyses.append(analyze(o, names, matcher))
    if save_ocr:
        Path(save_ocr).write_text(json.dumps(dumps, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"OCR の結果を保存しました: {save_ocr}")
    if not names.items:
        print("※ 装備名の一覧がありません。「データ更新」を実行すると、フレーム・武器名も読み取れるようになります。")
    print_analysis(merge(analyses) if len(analyses) > 1 else {**analyses[0], "images": 1})
