"""名前辞書: 公式 Public Export から名前・MOD・マスター・アルケイン・Riven 性質の一覧を作る(純粋な処理)"""
from __future__ import annotations

import re

from wfp.core.common import rank
from wfp.core.const import (
    ARCANE_CATS, ARCANE_PREFIX_CAT, ARCANE_UNRELEASED, DISPO_CATS, ERA_JA, ITEM_TYPES, MASTERY_CATS, MASTERY_FOUNDER,
    MASTERY_MAX_RANK, MOD_TYPES, PART_JA, PART_QUALIFIERS, PART_SKIP_CATS, PART_WORDS,
)


_MASTERY_WEAPON = {"LongGuns": "primary", "Pistols": "secondary", "Melee": "melee", "SpaceGuns": "archgun",
                   "SpaceMelee": "archmelee", "SentinelWeapons": "robotic", "OperatorAmps": "amp"}
# ExportWarframes の productCategory -> マスター一覧のカテゴリー
_MASTERY_SUIT = {"Suits": "warframe", "SpaceSuits": "archwing", "MechSuits": "necramech"}
# 200/ランクのカテゴリー(robotic はセンチネル本体だけなので mastery_xp で別に判定)
_MASTERY_XP_200 = ("warframe", "companion", "archwing", "necramech", "kdrive")


# パーツ検索の部品名・区分(Names.part_of は小文字で比べる)
_PART_WORDS = frozenset(w.lower() for w in PART_WORDS)
_PART_QUALIFIERS = frozenset(w.lower() for w in PART_QUALIFIERS)
# レリックの名前(例: "Lith A1 Relic")
_RELIC_NAME = re.compile(rf"^({'|'.join(ERA_JA)}) (\S+) Relic$")


# 組み立て式の部品。マスタリー経験値が入る部品(下の mastery_slots)以外は一覧に載せない
_MODULAR_PARTS = re.compile(r"/(OperatorAmplifiers|ModularMelee[^/]*|SUModular[^/]*|InfKitGun|Hoverboard|ZanukaPetParts|MoaPetParts)/")
# MOA・ハウンドの頭(Model)。マスタリー経験値が入る部品なので、組み立て部品の除外より前にロボティックとして拾う
# (Core・Bracket・Gyro・Stabilizer は入れない)。Nychus は内部名が MoaPetHeadMelee、ハウンドは HeadA〜C
_COMPANION_HEAD = re.compile(r"/(MoaPets/MoaPetParts/MoaPetHead[^/]+|ZanukaPets/ZanukaPetParts/ZanukaPetPartHead[A-Z])$")
# 図鑑に載らない印(excludeFromCodex)が付いているが、マスタリー経験値が入るもの。
# ハウンドの武器 Akaten / Batoten / Lacerten(SentinelWeapons。内部名は ZanukaPetMeleeWeapon PS / IP / IS)
# クエスト: ExportKeys のうち内部パスが「…KeyChain」「…KeyChainItem」「…KeyChainA」などのもの。
# parentName があるもの(暗殺キーなど)とクランキー(DojoKey)は入らない
_QUEST_KEY = re.compile(r"KeyChain(Item|[A-Z])?$")
_MASTERY_CODEX_EXEMPT = re.compile(r"/ZanukaPets/ZanukaPetMeleeWeapon[^/]+$")


def mastery_slots(export: str, it: dict) -> list[tuple[str, str]]:
    """Public Export の1項目が、マスター一覧のどのカテゴリーに入るか -> [(カテゴリー, 区分)]

    - 組み立て式は、マスタリー経験値が入る部品だけ: Kitgun はチェンバー(プライマリ版とセカンダリ版を別に数える)、
      Zaw はストライク、アンプはプリズム(と Sirocco)、Kドライブはボード(Deck)
    - アビリティ専用武器やコンクラーヴ用など、図鑑に載らないもの(excludeFromCodex)は除く。
      ただしハウンドの武器(_MASTERY_CODEX_EXEMPT)は印が付いていても載せる
    """
    uid, pc = it.get("uniqueName", ""), it.get("productCategory")
    if not it.get("name") or (it.get("excludeFromCodex") and not _MASTERY_CODEX_EXEMPT.search(uid)):
        return []
    if export == "ExportWarframes":
        return [(_MASTERY_SUIT[pc], "")] if pc in _MASTERY_SUIT else []
    if export == "ExportSentinels":
        return [("robotic", "")] if pc == "Sentinels" else [("companion", "")] if pc == "KubrowPets" else []
    if export != "ExportWeapons":
        return []
    if re.search(r"/OperatorAmplifiers/.*Barrel", uid):
        return [("amp", "")]
    if re.search(r"/ModularMelee[^/]*/Tips?/", uid):
        return [("zaw", "")]
    if re.search(r"/(SUModularSecondary[^/]*/Barrel|InfKitGun/Barrels)/", uid):
        return [("kitgun", "primary"), ("kitgun", "secondary")]
    # Kドライブ: ExportWeapons に productCategory "Pistols" で入っている。ボード以外(ノーズ・リアクター・ジェット)は対象外
    if re.search(r"/Hoverboard/.*Deck$", uid):
        return [("kdrive", "")]
    if _COMPANION_HEAD.search(uid):
        return [("robotic", "")]
    if _MODULAR_PARTS.search(uid):
        return []
    return [(_MASTERY_WEAPON[pc], "")] if pc in _MASTERY_WEAPON else []


def mastery_xp(cat: str, export: str, rank: int, uid: str = "") -> int:
    """ランク最大までのマスタリー経験値: フレーム・コンパニオン・センチネル本体・MOA/ハウンド(頭)・アークウイング・
    ネクロメカ・Kドライブは 200/ランク、武器は 100/ランク"""
    per = 200 if (cat in _MASTERY_XP_200 or (cat == "robotic" and export == "ExportSentinels")
                  or _COMPANION_HEAD.search(uid)) else 100
    return per * rank


_DISPO_TYPE = {"secondary": "Pistol Riven Mod", "melee": "Melee Riven Mod", "kitgun": "Kitgun Riven Mod",
               "zaw": "Zaw Riven Mod", "archgun": "Archgun Riven Mod", "robotic": "Companion Weapon Riven Mod"}


def arcane_cat(name: str) -> str:
    """アルケインの装備先カテゴリー (ARCANE_CATS のキー)"""
    first = name.strip().split(" ", 1)[0].lower()
    return ARCANE_PREFIX_CAT.get(first, "other")


# プライマリのうちショットガン用 Riven を使う武器。公式データに武器の種類が無いため、内部名に Shotgun を含むものと
# 下の名前(Prime・Kuva などを外した元の名前)で判定する。Riven 相場のデータがあれば、そちらの武器種を優先する
SHOTGUN_BASES = {"strun", "hek", "boar", "sobek", "felarx", "steflos", "corinth", "astilla", "cedo", "phantasma",
                 "rauta", "tigris", "phage", "bassocyst", "arca plasmor", "exergis", "kohm", "drakgoon", "bubonico"}


_VARIANT_WORDS = {"prime", "wraith", "vandal", "kuva", "tenet", "coda", "prisma", "sancti", "vaykor", "mara", "dex",
                  "rakta", "telos", "synoid", "secura", "mutalist", "carmine", "proboscis", "ceti"}


def weapon_base_name(name: str) -> str:
    """Prime・Kuva・MK1- などを外した元の武器名 (例: "Kuva Hek" -> "hek")"""
    words = re.sub(r"^mk1-", "", name.strip().lower()).split()
    return " ".join(x for x in words if x not in _VARIANT_WORDS)


def dispo_type(cat: str, uid: str, name: str) -> str:
    """Riven の種類 (RIVEN_TYPES_JA のキー)"""
    if cat == "primary":
        shotgun = "shotgun" in uid.lower() or weapon_base_name(name) in SHOTGUN_BASES
        return "Shotgun Riven Mod" if shotgun else "Rifle Riven Mod"
    return _DISPO_TYPE[cat]


def dispo_dots(value: float) -> int:
    """性質値 -> ●の数: 0.5〜0.7 / 0.71〜0.9 / 0.91〜1.10 / 1.11〜1.30 / 1.31〜1.55"""
    v = round(value, 2)
    return 1 if v <= 0.70 else 2 if v <= 0.90 else 3 if v <= 1.10 else 4 if v <= 1.30 else 5


def mod_type_key(it: dict) -> str:
    t = it.get("type") or ""
    if "/Necromech/" in it.get("uniqueName", ""):
        return "NECRAMECH"
    return t if t in MOD_TYPES else "OTHER"


def is_listed_mod(it: dict) -> bool:
    """MOD一覧に載せる MOD か(Riven・コンクラーヴ用・初心者用(欠陥)・変換コアは除く)"""
    uid, name = it.get("uniqueName", ""), it.get("name", "")
    return bool(name) and not (
        "Riven Mod" in name or "/PvPMods/" in uid or "/Beginner/" in uid or "/TransmuteCores/" in uid
        or "/Randomized/" in uid)


def _collect_names(docs: list[dict]) -> dict[str, tuple[str, str]]:
    """Export の各ファイルから uniqueName -> (名前, ファイルの種類 ExportResources など) を集める"""
    out = {}
    for doc in docs:
        for key, val in doc.items():
            if not isinstance(val, list):
                continue
            for it in val:
                if isinstance(it, dict) and it.get("uniqueName") and it.get("name"):
                    out[it["uniqueName"]] = (it["name"], key)
    return out


def _pair_names(en: dict[str, tuple[str, str]], other: dict[str, tuple[str, str]]) -> dict[str, str]:
    """_collect_names の英語版とほかの言語版を uniqueName で突き合わせ、英名 -> その言語の名前にする(同じ英名は最初のもの)"""
    out: dict[str, str] = {}
    for uid, (en_name, _kind) in en.items():
        if uid in other:
            out.setdefault(en_name, other[uid][0])
    return out


def names_by_lang(en_docs: list[dict], lang_docs: list[dict]) -> dict[str, str]:
    """Export の英語版とほかの言語版から、英名 -> その言語の名前の辞書を作る(names.json の en2ja と同じ作り方)"""
    return _pair_names(_collect_names(en_docs), _collect_names(lang_docs))


def is_quest_key(it: dict) -> bool:
    """ExportKeys の項目がクエストか(内部パスの形と、parentName が空であること)"""
    return bool(_QUEST_KEY.search(it.get("uniqueName") or "")) and not it.get("parentName")


def quest_names(en_docs: list[dict], ja: dict[str, tuple[str, str]]) -> list[dict]:
    """クエストの名前 [{id: 内部パス, en, ja}](英名順)。前提条件は同梱の data/quests/flow.json(core.quests)"""
    out: dict[str, dict] = {}
    for doc in en_docs:
        for it in doc.get("ExportKeys", []):
            if isinstance(it, dict) and isinstance(it.get("name"), str) and it["name"].strip() and is_quest_key(it):
                uid = it["uniqueName"]
                out.setdefault(uid, {"id": uid, "en": it["name"].strip(), "ja": ja.get(uid, (it["name"],))[0].strip()})
    return sorted(out.values(), key=lambda q: q["en"].lower())


def _strip_tag(name: str) -> str:
    """名前の頭の <タグ>(例: <ARCHWING>)と前後の空白を外す"""
    return re.sub(r"^<[^>]+>\s*", "", name).strip()


def _ja_name(ja: dict, uid: str, fallback: str) -> str:
    """uniqueName の和名(_collect_names の日本語版。無ければ fallback)"""
    return ja.get(uid, (fallback,))[0]


def _mod_entries(en_docs: list[dict], ja: dict) -> dict[str, dict]:
    """MOD 一覧用の情報(種別・極性・レア度など)。{英名(小文字): 行}。同じ名前は最初の1件"""
    mods: dict[str, dict] = {}
    for doc in en_docs:
        for it in doc.get("ExportUpgrades", []):
            if not isinstance(it, dict) or not is_listed_mod(it):
                continue
            name = it["name"]
            if name.lower() in mods:
                continue
            compat = it.get("compatName") or ""
            mods[name.lower()] = {
                "en": name, "ja": _ja_name(ja, it["uniqueName"], name),
                "type": mod_type_key(it), "polarity": it.get("polarity") or "",
                "rarity": (it.get("rarity") or "").capitalize(),
                "compat": compat if compat.upper() != compat else "",  # "WARFRAME" 等の汎用名は省く
                "drain": it.get("baseDrain"), "max_rank": it.get("fusionLimit"),
            }
    return mods


def _item_entries(en_docs: list[dict], ja: dict) -> dict[str, dict]:
    """画像解析で照合する装備名(フレーム・武器・コンパニオン。ITEM_TYPES の productCategory だけ)。{英名(小文字): 行}"""
    items: dict[str, dict] = {}
    for doc in en_docs:
        for key in ("ExportWarframes", "ExportWeapons", "ExportSentinels"):
            for it in doc.get(key, []):
                if not isinstance(it, dict) or it.get("productCategory") not in ITEM_TYPES:
                    continue
                name = _strip_tag(it.get("name", ""))
                if name and name.lower() not in items:
                    items[name.lower()] = {"en": name, "ja": _strip_tag(_ja_name(ja, it["uniqueName"], name)),
                                           "type": ITEM_TYPES[it["productCategory"]]}
    return items


def _arcane_entries(en_docs: list[dict], ja: dict) -> tuple[dict[str, str], dict[str, dict]]:
    """アルケイン名(画像解析の照合用)と所持一覧用の行。({英名(小文字): 英名}, {英名(小文字): 行})"""
    arcanes: dict[str, str] = {}
    arcane_list: dict[str, dict] = {}
    for doc in en_docs:
        for it in doc.get("ExportRelicArcane", []):
            name = it.get("name", "") if isinstance(it, dict) else ""
            if not name or name.endswith(" Relic") or "/CosmeticEnhancers/" not in it.get("uniqueName", ""):
                continue
            arcanes.setdefault(name.lower(), name)
            # 所持一覧は図鑑に載るものだけ (Arcane Steadfast の内部用の項目などを除く)。最大ランク = 段階の数 - 1
            # レア度: ExportRelicArcane はコモンのアルケインの一部で rarity を省いているため、無ければコモン
            #   (2026-10 時点で省かれている 21 件のうち、WFCD warframe-items に値がある 17 件はすべて Common。
            #    なお ExportUpgrades (MOD) はコモンも省かずに書いてある)
            levels = len(it.get("levelStats") or [])
            if (not it.get("excludeFromCodex") and levels >= 2 and name.lower() not in arcane_list
                    and it.get("uniqueName") not in ARCANE_UNRELEASED):
                arcane_list[name.lower()] = {
                    "en": name, "ja": _ja_name(ja, it["uniqueName"], name), "cat": arcane_cat(name),
                    "rarity": (it.get("rarity") or "COMMON").capitalize(), "max_rank": levels - 1}
    return arcanes, arcane_list


def _mastery_entries(en_docs: list[dict], ja: dict) -> dict[str, dict]:
    """マスター一覧の行(区分は mastery_slots。Kitgun などは variant 付き)。{id: 行}"""
    mastery: dict[str, dict] = {}
    for doc in en_docs:
        for key in ("ExportWarframes", "ExportWeapons", "ExportSentinels"):
            for it in doc.get(key, []):
                if not isinstance(it, dict):
                    continue
                name = _strip_tag(it.get("name", ""))
                for cat, variant in mastery_slots(key, it):
                    mid = f"{cat}:{variant}:{name.lower()}" if variant else f"{cat}:{name.lower()}"
                    if mid in mastery:
                        continue
                    rank = int(it.get("maxLevelCap") or MASTERY_MAX_RANK.get(cat, 30))
                    mastery[mid] = {"id": mid, "en": name, "cat": cat, "variant": variant, "rank": rank,
                                    "ja": _strip_tag(_ja_name(ja, it["uniqueName"], name)),
                                    "xp": mastery_xp(cat, key, rank, it.get("uniqueName", ""))}
    return mastery


def _dispo_entries(en_docs: list[dict], ja: dict) -> dict[str, dict]:
    """Riven 性質 (マスター一覧と同じ数え方の武器から、Riven を付けられないアークウイング近接・アンプを除く)。{id: 行}"""
    dispo: dict[str, dict] = {}
    for doc in en_docs:
        for it in doc.get("ExportWeapons", []):
            if not isinstance(it, dict) or not isinstance(it.get("omegaAttenuation"), (int, float)):
                continue
            if _COMPANION_HEAD.search(it.get("uniqueName", "")) or _MASTERY_CODEX_EXEMPT.search(it.get("uniqueName", "")):
                continue  # MOA・ハウンドの頭とハウンドの武器はマスター一覧(robotic)だけ。Riven 性質には今まで通り出さない
            name = _strip_tag(it.get("name", ""))
            for cat, variant in mastery_slots("ExportWeapons", it):
                if cat not in DISPO_CATS:
                    continue
                did = f"{cat}:{variant}:{name.lower()}" if variant else f"{cat}:{name.lower()}"
                if did in dispo:
                    continue
                # Kitgun のプライマリ版は primeOmegaAttenuation (無ければセカンダリ版と同じ値)
                raw = it.get("primeOmegaAttenuation") if variant == "primary" else None
                value = round(float(raw if isinstance(raw, (int, float)) else it["omegaAttenuation"]), 2)
                dispo[did] = {"id": did, "en": name, "cat": cat, "variant": variant, "value": value,
                              "type": dispo_type(cat, it.get("uniqueName", ""), name),
                              "ja": _strip_tag(_ja_name(ja, it["uniqueName"], name))}
    return dispo


def names_from_exports(en_docs: list[dict], ja_docs: list[dict]) -> dict:
    """Export の英語版・日本語版を uniqueName で突き合わせて辞書化する(種類ごとの _*_entries を集めて並べる)"""
    en, ja = _collect_names(en_docs), _collect_names(ja_docs)
    resources = [en_name for _uid, (en_name, kind) in en.items() if kind == "ExportResources"]
    arcanes, arcane_list = _arcane_entries(en_docs, ja)
    order = {c: i for i, c in enumerate(MASTERY_CATS)}
    return {"quests": quest_names(en_docs, ja), "en2ja": _pair_names(en, ja), "resources": sorted(set(resources)),
            "mods": sorted(_mod_entries(en_docs, ja).values(), key=lambda m: m["en"].lower()),
            "items": sorted(_item_entries(en_docs, ja).values(), key=lambda m: m["en"].lower()),
            "arcanes": sorted(arcanes.values(), key=str.lower),
            "arcane_list": sorted(arcane_list.values(), key=lambda m: (list(ARCANE_CATS).index(m["cat"]), m["en"].lower())),
            "mastery": sorted(_mastery_entries(en_docs, ja).values(), key=lambda m: (order[m["cat"]], m["en"].lower(), m["variant"])),
            "dispo": sorted(_dispo_entries(en_docs, ja).values(),
                            key=lambda m: (list(DISPO_CATS).index(m["cat"]), -m["value"], m["en"].lower(), m["variant"]))}


class Names:
    def __init__(self, en2ja: dict | None = None, resources: list | None = None, mods: list | None = None,
                 items: list | None = None, arcanes: list | None = None, mastery: list | None = None,
                 dispo: list | None = None, arcane_list: list | None = None, quests: list | None = None):
        self.en2ja = en2ja or {}
        self.quests = quests or []    # クエスト [{id, en, ja}](Export の分。前提条件は core.quests)
        self.resources = set(resources or [])
        self.mods = mods or []
        self.items = items or []      # 装備名 [{en, ja, type}] (画像解析用)
        self.arcanes = arcanes or []  # アルケイン名 (画像解析用)
        self.mastery = mastery or []  # マスター一覧 [{id, en, ja, cat, variant, rank, xp}]
        self.dispo = dispo or []      # Riven 性質 [{id, en, ja, cat, variant, value, type}]
        self.arcane_list = arcane_list or []  # アルケイン所持一覧 [{en, ja, cat, rarity, max_rank}]
        # ドロップ表と公式データで大文字小文字が違うことがある(例: "Bane Of Grineer" / "Bane of Grineer")
        self._lower = {k.lower(): v for k, v in self.en2ja.items()}
        self._res_lower = {r.lower() for r in self.resources}
        self._mod_lower = {m["en"].lower() for m in self.mods if isinstance(m, dict) and isinstance(m.get("en"), str)}
        self._parts: dict[str, tuple[str, str]] | None = None  # パーツ検索用 {本体の英名(小文字): (英名, カテゴリー)}。初回に作る

    @classmethod
    def from_json(cls, j: dict | None) -> "Names":
        """names.json の中身から作る。None なら空の辞書"""
        if j is None:
            return cls()
        return cls(j.get("en2ja"), j.get("resources"), j.get("mods"), j.get("items"), j.get("arcanes"), j.get("mastery"),
                   j.get("dispo"), j.get("arcane_list"), j.get("quests"))

    @staticmethod
    def split_qty(name: str) -> tuple[str, str]:
        m = re.match(r"^([\d,]+)X\s+(.*)$", name)
        return (m.group(1), m.group(2)) if m else ("", name)

    def _get(self, en: str) -> str | None:
        return self.en2ja.get(en) or self._lower.get(en.lower())

    def is_mod(self, name: str) -> bool:
        """MOD の英名か(大文字小文字は区別しない完全一致。Riven は含めない)"""
        return name.strip().lower() in self._mod_lower

    def has(self, name: str) -> bool:
        """名前辞書に載っている英名か(大文字小文字は区別しない完全一致。個数の付いた名前・和名は見ない)"""
        return self._get(name.strip()) is not None

    def ja(self, name: str) -> str:
        qty, base = self.split_qty(name)
        pre = f"{qty}個 " if qty else ""
        if hit := self._get(base):
            return pre + hit
        if m := re.match(r"^([\d,]+) Credits Cache$", base):
            return f"{m.group(1)} クレジットキャッシュ"
        if m := re.match(r"^([\d,]+) Credits$", base):
            return f"{m.group(1)} クレジット"
        if m := re.match(r"^([\d,]+) Endo$", base):
            return f"{m.group(1)} エンド"
        if m := _RELIC_NAME.match(base):
            return f"{ERA_JA[m.group(1)]} {m.group(2)} レリック"
        if base.endswith(" Blueprint"):
            b = base[:-10]
            if hit := self._get(b):
                return hit + " 設計図"
            words = b.split(" ")
            if len(words) > 1 and words[-1] in PART_JA and (first := self._get(words[0])):
                return f"{first} {PART_JA[words[-1]]} 設計図"
        return pre + base

    def is_resource(self, name: str) -> bool:
        return self.split_qty(name)[1].lower() in self._res_lower

    def item_kind(self, name: str, owners: dict[str, str] | None = None) -> str:
        """アイテムの種類(AREA_KINDS のキー)。エリア検索・アイテムから探すで共用。
        パーツ・設計図(part_of。owners は part_of と同じ)→ 素材 → MOD(Riven を含む)→ レリック → その他 の順に見る"""
        base = self.split_qty(name)[1]
        if self.part_of(base, owners):
            return "part"
        if self.is_resource(base):
            return "resource"
        if self.is_mod(base) or base.endswith(" Riven Mod"):
            return "mod"
        if self.relic_era(base):
            return "relic"
        return "other"

    def relic_era(self, name: str) -> tuple[str, str] | None:
        """レリックなら (時代(ERA_JA のキー。例: Lith), 記号(例: A1))、違えば None。数量の付いた名前でもよい"""
        m = _RELIC_NAME.match(self.split_qty(name)[1])
        return (m.group(1), m.group(2)) if m else None

    def part_of(self, name: str, owners: dict[str, str] | None = None) -> tuple[str, str] | None:
        """パーツ(Warframe・武器などの本体・設計図・パーツ)なら (本体の英名, マスター一覧のカテゴリー)、違えば None。

        「本体名 + 部品名(PART_WORDS。前に PART_QUALIFIERS が付くことがある)+ Blueprint」の形だけを拾う。
        本体名は一番長く一致するもの(例: "Lato Prime Barrel" は Lato ではなく Lato Prime)。
        owners({item_key: 本体の英名}。同梱データの extras = Sources.part_owner)を渡すと、
        設計図ではない作成素材(例: Mandachord)も本体(Octavia)のパーツとして扱う
        """
        hit = self._part_by_name(name)
        if hit is None and owners and (owner := owners.get(item_key(name))):
            hit = self._part_by_name(owner)
        return hit

    def _part_by_name(self, name: str) -> tuple[str, str] | None:
        """part_of の名前だけで見る部分"""
        if self._parts is None:
            self._parts = {}
            for m in sorted(self.mastery, key=lambda m: list(MASTERY_CATS).index(m["cat"]) if m["cat"] in MASTERY_CATS else 99):
                if m["cat"] not in PART_SKIP_CATS and m.get("id") not in MASTERY_FOUNDER:  # ファウンダー限定品も除く
                    self._parts.setdefault(m["en"].lower(), (m["en"], m["cat"]))
        words = self.split_qty(name)[1].lower().split()  # ドロップ表と公式データで大文字小文字が違うことがあるので小文字でそろえる
        if words and words[-1] == "blueprint":
            words = words[:-1]
        for i in range(len(words), 0, -1):
            hit = self._parts.get(" ".join(words[:i]))
            if hit is None:
                continue
            rest = words[i:]
            if len(rest) > 1 and rest[0] in _PART_QUALIFIERS:
                rest = rest[1:]
            return hit if not rest or " ".join(rest) in _PART_WORDS else None
        return None


def item_key(name: str) -> str:
    """数量違い(例: 2X Neurodes / Neurodes)や大文字小文字の違いを同じ項目として扱うためのキー"""
    return Names.split_qty(name)[1].lower()


# 内部パス → 英語名(item_paths.json。データ更新で作り、バロ吉・侵略サイクルで World State の内部パスを名前にする。
# 2026-11-10 に wfportal_baro から移した)
def item_paths_from_exports(en_docs: list[dict]) -> dict:
    """{内部パス: 英語名}。設計図 (ExportRecipes) は「作れるものの名前 + Blueprint」"""
    names, recipes = {}, {}
    for doc in en_docs:
        for key, val in doc.items():
            if not isinstance(val, list):
                continue
            for it in val:
                if not isinstance(it, dict) or not isinstance(it.get("uniqueName"), str):
                    continue
                if it.get("name"):
                    names.setdefault(it["uniqueName"], it["name"])
                elif key == "ExportRecipes" and isinstance(it.get("resultType"), str):
                    recipes[it["uniqueName"]] = it["resultType"]
    for uid, result in recipes.items():
        if result in names:
            names.setdefault(uid, f"{names[result]} Blueprint")
    return names
